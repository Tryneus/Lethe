// Copyright (c) 2009, 2010 Paul Pogonyshev.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.


#ifndef MCT_HASH_MAP_HPP
#define MCT_HASH_MAP_HPP


#include <mct/config.hpp>
#include <mct/intrusiveness.hpp>
#include <mct/impl/closed-hash-table.hpp>

#include MCT_HASH_HEADER


namespace mct
{

  namespace impl
  {

    template <typename Key, typename Mapped>
    struct map_bucket_traits
    {
      typedef  std::pair <const Key, Mapped>  value_type;
      typedef  value_type                     assignable_value_type;
      typedef  Key                            key_type;

      static  const key_type&
      extract_key (const value_type& value)
      {  return value.first;  }
    };


    // FIXME: Too much code duplication to my liking.  How to reuse code?

    template <typename Key, typename Mapped, bool keep_hashes>
    class map_bucket : public plain_bucket_base <map_bucket_traits <Key, Mapped>, keep_hashes>
    {
      typedef  plain_bucket_base <map_bucket_traits <Key, Mapped>, keep_hashes>  base_type;

    public:

      typedef  typename base_type::key_type                                      key_type;
      typedef  Mapped                                                            mapped_type;
      typedef  typename base_type::value_type                                    value_type;


      // We need to override functions that take 'value_type' reference as argument, else
      // they are not found.

      static  const key_type&
      extract_key (const value_type& value)
      {  return base_type::extract_key (value);  }

      static  const key_type&
      extract_key (const key_type& key)
      {  return key;  }


      template <typename Allocator>
      void
      construct_value (Allocator& allocator, const value_type& initializer)
      {
        allocator.construct (&this->value (), initializer);
      }

      template <typename Allocator>
      void
      construct_value (Allocator& allocator, const key_type& key)
      {
        allocator.construct (&this->value (), value_type (key, mapped_type ()));
      }

#   if MCT_CXX0X_SUPPORTED

      template <typename Allocator>
      void
      construct_value (Allocator& allocator, value_type&& initializer)
      {
        allocator.construct (&this->value (), std::forward <value_type> (initializer));
      }

      template <typename Allocator>
      void
      construct_value (Allocator& allocator, key_type&& key)
      {
        allocator.construct (&this->value (),
                             value_type (std::forward <key_type> (key), mapped_type ()));
      }

#   endif


      bool
      mapped_equal (const map_bucket& that) const
      {
        return this->value ().second == that.value ().second;
      }
    };


    template <typename Key, typename Mapped, bool keep_hashes>
    class linked_map_bucket
      : public linked_bucket_base <map_bucket_traits <Key, Mapped>, keep_hashes>
    {
      typedef  linked_bucket_base <map_bucket_traits <Key, Mapped>, keep_hashes>  base_type;

    public:

      typedef  typename base_type::key_type                                       key_type;
      typedef  Mapped                                                             mapped_type;
      typedef  typename base_type::value_type                                     value_type;


      // We need to override functions that take 'value_type' reference as argument, else
      // they are not found.

      static  const key_type&
      extract_key (const value_type& value)
      {  return base_type::extract_key (value);  }

      static  const key_type&
      extract_key (const key_type& key)
      {  return key;  }


      template <typename Allocator>
      void
      construct_value (Allocator& allocator, const value_type& initializer)
      {
        allocator.construct (&this->value (), initializer);
      }

      template <typename Allocator>
      void
      construct_value (Allocator& allocator, const key_type& key)
      {
        allocator.construct (&this->value (), value_type (key, mapped_type ()));
      }

#   if MCT_CXX0X_SUPPORTED

      template <typename Allocator>
      void
      construct_value (Allocator& allocator, value_type&& initializer)
      {
        allocator.construct (&this->value (), std::forward <value_type> (initializer));
      }

      template <typename Allocator>
      void
      construct_value (Allocator& allocator, key_type&& key)
      {
        allocator.construct (&this->value (),
                             value_type (std::forward <key_type> (key), mapped_type ()));
      }

#   endif


      bool
      mapped_equal (const linked_map_bucket& that) const
      {
        return this->value ().second == that.value ().second;
      }
    };


    template <typename Key, typename Mapped, bool keep_hashes>
    class forward_map_bucket
      : public forward_bucket_base <map_bucket_traits <Key, Mapped>, keep_hashes>
    {
      typedef  forward_bucket_base <map_bucket_traits <Key, Mapped>, keep_hashes>  base_type;

    public:

      typedef  typename base_type::key_type                                       key_type;
      typedef  Mapped                                                             mapped_type;
      typedef  typename base_type::value_type                                     value_type;


      // We need to override functions that take 'value_type' reference as argument, else
      // they are not found.

      static  const key_type&
      extract_key (const value_type& value)
      {  return base_type::extract_key (value);  }

      static  const key_type&
      extract_key (const key_type& key)
      {  return key;  }


      template <typename Allocator>
      void
      construct_value (Allocator& allocator, const value_type& initializer)
      {
        allocator.construct (&this->value (), initializer);
      }

      template <typename Allocator>
      void
      construct_value (Allocator& allocator, const key_type& key)
      {
        allocator.construct (&this->value (), value_type (key, mapped_type ()));
      }

#   if MCT_CXX0X_SUPPORTED

      template <typename Allocator>
      void
      construct_value (Allocator& allocator, value_type&& initializer)
      {
        allocator.construct (&this->value (), std::forward <value_type> (initializer));
      }

      template <typename Allocator>
      void
      construct_value (Allocator& allocator, key_type&& key)
      {
        allocator.construct (&this->value (),
                             value_type (std::forward <key_type> (key), mapped_type ()));
      }

#   endif


      bool
      mapped_equal (const forward_map_bucket& that) const
      {
        return this->value ().second == that.value ().second;
      }
    };

  }


  template <typename Key,
            typename Mapped,
            typename Hash        = MCT_HASH_NAMESPACE::hash <Key>,
            typename Equal       = std::equal_to <Key>,
            typename Allocator   = std::allocator <std::pair <const Key, Mapped> >,
            bool     keep_hashes = false>
  class closed_hash_map
    : public impl::closed_hash_table <impl::map_bucket <Key, Mapped, keep_hashes>,
                                      Hash, Equal, Allocator>
  {
  protected:

    typedef  impl::closed_hash_table <impl::map_bucket <Key, Mapped, keep_hashes>,
                                      Hash, Equal, Allocator>
             table_type;

    typedef  typename table_type::bucket_type  bucket_type;

  public:

    typedef  typename table_type::key_type     key_type;
    typedef  Mapped                            mapped_type;
    typedef  typename table_type::value_type   value_type;


    explicit
    closed_hash_map (size_t           num_buckets = 0,
                     const Hash&      hash        = Hash (),
                     const Equal&     equal       = Equal (),
                     const Allocator& allocator   = Allocator ())
      : table_type (num_buckets, hash, equal, allocator)
    { }

    closed_hash_map (const closed_hash_map& that, const Allocator& allocator)
      : table_type (that, allocator)
    { }
 
# if MCT_CXX0X_SUPPORTED

    closed_hash_map (closed_hash_map&& that)
      : table_type (std::move (that))
    { }

    closed_hash_map (std::initializer_list <value_type> initializer,
                     std::size_t      num_buckets = 0,
                     const Hash&      hash        = Hash (),
                     const Equal&     equal       = Equal (),
                     const Allocator& allocator   = Allocator ())
      : table_type (initializer, num_buckets, hash, equal, allocator)
    { }

# endif  // MCT_CXX0X_SUPPORTED

    template <typename InputIterator>
    closed_hash_map (InputIterator first, InputIterator last,
                     size_t           num_buckets = 0,
                     const Hash&      hash        = Hash (),
                     const Equal&     equal       = Equal (),
                     const Allocator& allocator   = Allocator ())
      : table_type (first, last, num_buckets, hash, equal, allocator)
    { }


    mapped_type&
    operator[] (const key_type& key)
    {
      return this->template lookup_or_insert <const key_type&> (key).first->value ().second;
    }

# if MCT_CXX0X_SUPPORTED

    mapped_type&
    operator[] (key_type&& key)
    {
      return (this->template lookup_or_insert <key_type&&> (std::forward <key_type> (key))
              .first->value ().second);
    }

# endif

    mapped_type&
    at (const key_type& key)
    {
      bucket_type* const  bucket = this->lookup (key);
      if (MCT_OPTIMIZATION_UNLIKELY (bucket == this->_data.end ()))
        throw std::out_of_range ("closed_hash_map::at");

      return bucket->value ().second;
    }

    const mapped_type&
    at (const key_type& key) const
    {
      bucket_type* const  bucket = this->lookup (key);
      if (MCT_OPTIMIZATION_UNLIKELY (bucket == this->_data.end ()))
        throw std::out_of_range ("closed_hash_map::at");

      return bucket->value ().second;
    }


    closed_hash_map&
    operator= (const closed_hash_map& that)
    {
      return static_cast <closed_hash_map&> (table_type::operator= (that));
    }

# if MCT_CXX0X_SUPPORTED

    closed_hash_map&
    operator= (closed_hash_map&& that)
    {
      return static_cast <closed_hash_map&> (table_type::operator= (std::move (that)));
    }

    closed_hash_map&
    operator= (std::initializer_list <value_type> initializer)
    {
      return static_cast <closed_hash_map&> (table_type::operator= (initializer));
    }

# endif  // MCT_CXX0X_SUPPORTED
  };


  template <typename Key,
            typename Mapped,
            typename Hash        = MCT_HASH_NAMESPACE::hash <Key>,
            typename Equal       = std::equal_to <Key>,
            typename Allocator   = std::allocator <std::pair <const Key, Mapped> >,
            bool     keep_hashes = false>
  class linked_hash_map
    : public impl::linked_hash_table <impl::linked_map_bucket <Key, Mapped, keep_hashes>,
                                      Hash, Equal, Allocator>
  {
  protected:

    typedef  impl::linked_hash_table <impl::linked_map_bucket <Key, Mapped, keep_hashes>,
                                      Hash, Equal, Allocator>
             table_type;

    typedef  typename table_type::bucket_type  bucket_type;

  public:

    typedef  typename table_type::key_type     key_type;
    typedef  Mapped                            mapped_type;
    typedef  typename table_type::value_type   value_type;


    explicit
    linked_hash_map (size_t           num_buckets = 0,
                     const Hash&      hash        = Hash (),
                     const Equal&     equal       = Equal (),
                     const Allocator& allocator   = Allocator ())
      : table_type (num_buckets, hash, equal, allocator)
    { }

    linked_hash_map (const linked_hash_map& that, const Allocator& allocator)
      : table_type (that, allocator)
    { }

# if MCT_CXX0X_SUPPORTED

    linked_hash_map (linked_hash_map&& that)
      : table_type (std::move (that))
    { }

    linked_hash_map (std::initializer_list <value_type> initializer,
                     std::size_t      num_buckets = 0,
                     const Hash&      hash        = Hash (),
                     const Equal&     equal       = Equal (),
                     const Allocator& allocator   = Allocator ())
      : table_type (initializer, num_buckets, hash, equal, allocator)
    { }

# endif  // MCT_CXX0X_SUPPORTED

    template <typename InputIterator>
    linked_hash_map (InputIterator first, InputIterator last,
                     size_t           num_buckets = 0,
                     const Hash&      hash        = Hash (),
                     const Equal&     equal       = Equal (),
                     const Allocator& allocator   = Allocator ())
      : table_type (first, last, num_buckets, hash, equal, allocator)
    { }


    mapped_type&
    operator[] (const key_type& key)
    {
      return (this->template lookup_or_insert <const key_type&> (key, this->_data.end ())
              .first->value ().second);
    }

# if MCT_CXX0X_SUPPORTED

    mapped_type&
    operator[] (key_type&& key)
    {
      return (this->template lookup_or_insert <key_type&&> (std::forward <key_type> (key),
                                                            this->_data.end ())
              .first->value ().second);
    }

# endif


    mapped_type&
    at (const key_type& key)
    {
      bucket_type* const  bucket = this->lookup (key);
      if (MCT_OPTIMIZATION_UNLIKELY (bucket == this->_data.end ()))
        throw std::out_of_range ("linked_hash_map::at");

      return bucket->value ().second;
    }

    const mapped_type&
    at (const key_type& key) const
    {
      bucket_type* const  bucket = this->lookup (key);
      if (MCT_OPTIMIZATION_UNLIKELY (bucket == this->_data.end ()))
        throw std::out_of_range ("linked_hash_map::at");

      return bucket->value ().second;
    }


    linked_hash_map&
    operator= (const linked_hash_map& that)
    {
      return static_cast <linked_hash_map&> (table_type::operator= (that));
    }

# if MCT_CXX0X_SUPPORTED

    linked_hash_map&
    operator= (linked_hash_map&& that)
    {
      return static_cast <linked_hash_map&> (table_type::operator= (std::move (that)));
    }

    linked_hash_map&
    operator= (std::initializer_list <value_type> initializer)
    {
      return static_cast <linked_hash_map&> (table_type::operator= (initializer));
    }

# endif  // MCT_CXX0X_SUPPORTED
  };


  template <typename Key,
            typename Mapped,
            typename Hash        = MCT_HASH_NAMESPACE::hash <Key>,
            typename Equal       = std::equal_to <Key>,
            typename Allocator   = std::allocator <std::pair <const Key, Mapped> >,
            bool     keep_hashes = false>
  class forward_hash_map
    : public impl::forward_hash_table <impl::forward_map_bucket <Key, Mapped, keep_hashes>,
                                       Hash, Equal, Allocator>
  {
  protected:

    typedef  impl::forward_hash_table <impl::forward_map_bucket <Key, Mapped, keep_hashes>,
                                       Hash, Equal, Allocator>
             table_type;

    typedef  typename table_type::bucket_type  bucket_type;

  public:

    typedef  typename table_type::key_type     key_type;
    typedef  Mapped                            mapped_type;
    typedef  typename table_type::value_type   value_type;


    explicit
    forward_hash_map (size_t           num_buckets = 0,
                      const Hash&      hash        = Hash (),
                      const Equal&     equal       = Equal (),
                      const Allocator& allocator   = Allocator ())
      : table_type (num_buckets, hash, equal, allocator)
    { }

    forward_hash_map (const forward_hash_map& that, const Allocator& allocator)
      : table_type (that, allocator)
    { }

# if MCT_CXX0X_SUPPORTED

    forward_hash_map (forward_hash_map&& that)
      : table_type (std::move (that))
    { }

    forward_hash_map (std::initializer_list <value_type> initializer,
                      std::size_t      num_buckets = 0,
                      const Hash&      hash        = Hash (),
                      const Equal&     equal       = Equal (),
                      const Allocator& allocator   = Allocator ())
      : table_type (initializer, num_buckets, hash, equal, allocator)
    { }

# endif  // MCT_CXX0X_SUPPORTED

    template <typename InputIterator>
    forward_hash_map (InputIterator first, InputIterator last,
                      size_t           num_buckets = 0,
                      const Hash&      hash        = Hash (),
                      const Equal&     equal       = Equal (),
                      const Allocator& allocator   = Allocator ())
      : table_type (first, last, num_buckets, hash, equal, allocator)
    { }


    mapped_type&
    operator[] (const key_type& key)
    {
      return (this->template lookup_or_insert <const key_type&> (key, this->_data.back)
              .first->value ().second);
    }

# if MCT_CXX0X_SUPPORTED

    mapped_type&
    operator[] (key_type&& key)
    {
      return (this->template lookup_or_insert <key_type&&> (std::forward <key_type> (key),
                                                            this->_data.back)
              .first->value ().second);
    }

# endif


    mapped_type&
    at (const key_type& key)
    {
      bucket_type* const  bucket = this->lookup (key);
      if (MCT_OPTIMIZATION_UNLIKELY (bucket == this->_data.end ()))
        throw std::out_of_range ("forward_hash_map::at");

      return bucket->value ().second;
    }

    const mapped_type&
    at (const key_type& key) const
    {
      bucket_type* const  bucket = this->lookup (key);
      if (MCT_OPTIMIZATION_UNLIKELY (bucket == this->_data.end ()))
        throw std::out_of_range ("forward_hash_map::at");

      return bucket->value ().second;
    }


    forward_hash_map&
    operator= (const forward_hash_map& that)
    {
      return static_cast <forward_hash_map&> (table_type::operator= (that));
    }

# if MCT_CXX0X_SUPPORTED

    forward_hash_map&
    operator= (forward_hash_map&& that)
    {
      return static_cast <forward_hash_map&> (table_type::operator= (std::move (that)));
    }

    forward_hash_map&
    operator= (std::initializer_list <value_type> initializer)
    {
      return static_cast <forward_hash_map&> (table_type::operator= (initializer));
    }

# endif  // MCT_CXX0X_SUPPORTED
  };


  template <typename Key, typename Mapped, typename Hash, typename Equal, typename Allocator,
            bool keep_hashes>
  inline  void
  swap (closed_hash_map <Key, Mapped, Hash, Equal, Allocator, keep_hashes>& map1,
        closed_hash_map <Key, Mapped, Hash, Equal, Allocator, keep_hashes>& map2)
  {
    map1.swap (map2);
  }

  template <typename Key, typename Mapped, typename Hash, typename Equal, typename Allocator,
            bool keep_hashes>
  inline  void
  swap (linked_hash_map <Key, Mapped, Hash, Equal, Allocator, keep_hashes>& map1,
        linked_hash_map <Key, Mapped, Hash, Equal, Allocator, keep_hashes>& map2)
  {
    map1.swap (map2);
  }

  template <typename Key, typename Mapped, typename Hash, typename Equal, typename Allocator,
            bool keep_hashes>
  inline  void
  swap (forward_hash_map <Key, Mapped, Hash, Equal, Allocator, keep_hashes>& map1,
        forward_hash_map <Key, Mapped, Hash, Equal, Allocator, keep_hashes>& map2)
  {
    map1.swap (map2);
  }

}


#endif  // Multi-inclusion guard.


// Local variables:
// mode: c++
// c-basic-offset: 2
// indent-tabs-mode: nil
// fill-column: 90
// End:
