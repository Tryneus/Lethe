// Copyright (c) 2009, 2010 Paul Pogonyshev.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.


#ifndef MCT_IMPL_UTILS_HPP
#define MCT_IMPL_UTILS_HPP


#include <cmath>
#include <iterator>

#if MCT_HAVE_TYPE_TRAITS
# include MCT_TYPE_TRAITS_HEADER
#endif

#if MCT_ENABLE_DEBUGGING || MCT_CHECK_PRECONDITIONS || MCT_SELF_VALIDATION
# define MCT_DEBUGGING_MEMBERS  1
#else
# define MCT_DEBUGGING_MEMBERS  0
#endif


#if MCT_CHECK_PRECONDITIONS

# define MCT_PRECONDITION(condition, error_message)     \
  do                                                    \
    {                                                   \
      if (!(condition))                                 \
        throw std::logic_error (error_message);         \
    }                                                   \
  while (false)

#else
# define MCT_PRECONDITION(condition, error_message)
#endif


#if MCT_SELF_VALIDATION
# define MCT_VALIDATION(statement)      (statement)
#else
# define MCT_VALIDATION(statement)
#endif


namespace mct
{

  namespace impl
  {

# if MCT_SIZEOF_POINTER == MCT_SIZEOF_INT
    typedef  unsigned int        pointer_storage_type;
# elif MCT_SIZEOF_POINTER == MCT_SIZEOF_LONG
    typedef  unsigned long       pointer_storage_type;
# elif MCT_HAVE_LONG_LONG && MCT_SIZEOF_POINTER == MCT_SIZEOF_LONG_LONG
    typedef  unsigned long long  pointer_storage_type;
# else
#   error cannot pick an integral type with the same size as pointer
# endif


# if MCT_HAVE_TYPE_TRAITS

#   if defined (__GNUC__) && ((__GNUC__ == 4 && __GNUC_MINOR__ >= 3) || __GNUC__ > 4)

    // On GCC TR1 implementation provides subpar 'has_trivial_destructor', so we use the
    // built-in instead.
    template <typename type>
    struct has_trivial_destructor
    {
      static  const bool  value = __has_trivial_destructor (type);
    };

#   else

    using MCT_TYPE_TRAITS_NAMESPACE::has_trivial_destructor;

#   endif

# else

    // FIXME: Improve if needed.  Only used if STL doesn't provide type traits.
    template <typename type>
    struct has_trivial_destructor
    {
      static  const bool  value = false;
    };

# endif


    template <typename type>
    inline  type
    round_up_to_power_of_2 (type number)
    {
      if (number & (number - 1))
        {
          for (number <<= 1; number & (number - 1);)
            number &= (number - 1);
        }

      return number;
    }

    template <typename type>
    inline  type
    round_down_to_power_of_2 (type number)
    {
      while (number & (number - 1))
        number &= (number - 1);

      return number;
    }


    template <typename Iterator>
    inline  typename std::iterator_traits <Iterator>::difference_type
    forward_distance (Iterator first, Iterator last, std::input_iterator_tag)
    {
      // Cannot determine in general case.
      return 0;
    }

    template <typename Iterator>
    inline  typename std::iterator_traits <Iterator>::difference_type
    forward_distance (Iterator first, Iterator last, std::forward_iterator_tag)
    {
      return std::distance (first, last);
    }

    template <typename Iterator>
    inline  typename std::iterator_traits <Iterator>::difference_type
    forward_distance (Iterator first, Iterator last)
    {
      typedef  typename std::iterator_traits <Iterator>::iterator_category  category;
      return forward_distance (first, last, category ());
    }

    template <typename Iterator>
    inline  typename std::iterator_traits <Iterator>::difference_type
    forward_distance_scaled (Iterator first, Iterator last, float inverted_scale)
    {
      typedef  typename std::iterator_traits <Iterator>::iterator_category  category;
      return (static_cast <typename std::iterator_traits <Iterator>::difference_type>
              (std::ceil (forward_distance (first, last, category ()) / inverted_scale)));
    }


    template <bool condition, typename Type = void>
    struct enable_if
    { };

    template <typename Type>
    struct enable_if <true, Type>
    {
      typedef  Type  type;
    };

  }

}


#endif  // Multi-inclusion guard.


// Local variables:
// mode: c++
// c-basic-offset: 2
// indent-tabs-mode: nil
// fill-column: 90
// End:
