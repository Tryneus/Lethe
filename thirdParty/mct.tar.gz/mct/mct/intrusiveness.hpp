// Copyright (c) 2010 Paul Pogonyshev.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.


#ifndef MCT_INTRUSIVENESS_HPP
#define MCT_INTRUSIVENESS_HPP


#include <utility>

#include <mct/impl/utils.hpp>


namespace mct
{

  // Templated structure specifying how given type could be used by its container (in
  // broad sense), i.e. "externally".  Default is no external use; it can be enabled by
  // specializing the structure.
  template <typename Type, typename = void>
  struct external_use
  { };


  template <typename Type, typename = Type>
  struct supports_external_use
  {
    static  const bool  value = false;
  };

  template <typename Type>
  struct supports_external_use <Type, typename external_use <Type>::type>
  {
    static  const bool  value = true;
  };


  template <typename Type, typename Value, Value Type::* field>
  struct extern_use_field
  {
    typedef  Type   type;
    typedef  Value  value_type;

    static  const value_type&
    get (const type& structure)
    {  return structure.*field;  }

    static  void
    set (type& structure, const value_type& value)
    {  structure.*field = value;  }
  };

  template <typename To, typename From, From To::* field>
  struct propagate_external_use
  {
    typedef  To                                        type;
    typedef  typename external_use <From>::value_type  value_type;

    static  const value_type&
    get (const type& structure)
    {
      return external_use <From>::get (structure.*field);
    }

    static  void
    set (type& structure, const value_type& value)
    {
      external_use <From>::set (structure.*field, value);
    }
  };


  template <typename First, typename Second>
  struct external_use <std::pair <First, Second>,
                       typename impl::enable_if <supports_external_use <First>::value>::type>
    : propagate_external_use <std::pair <First, Second>, First,
                              &std::pair <First, Second>::first>
  { };

  template <typename First, typename Second>
  struct external_use <std::pair <First, Second>,
                       typename impl::enable_if <supports_external_use <Second>::value
                                                 && !supports_external_use <First>::value>::type>
    : propagate_external_use <std::pair <First, Second>, Second,
                              &std::pair <First, Second>::second>
  { };


  namespace impl
  {

    // The following wrappers over public interface are currently package-private and
    // undocumented as they don't look generally useful.  The whole purpose here is to
    // pass through constness of the first field in 'pair <const First, Second>' --- the
    // type that's stored in maps.
    //
    // Apparently, there is no way to store 'pair <K, M>' internally, but return a
    // reference to it as 'pair <const K, M>&' as required by interface (at least without
    // 'reinterpret_cast', but I'm afraid of type-punnig bugs).  So, maps do store the
    // first-field-is-const pairs, but 'const_cast' constness away when needed.  Since we
    // only need one level of this ugliness, 'hackish_external_use' is not recursive.

    template <typename Type, typename = void>
    struct hackish_external_use : external_use <Type>
    { };


    template <typename Type, typename = Type>
    struct supports_hackish_external_use
    {
      static  const bool  value = false;
    };

    template <typename Type>
    struct supports_hackish_external_use <Type, typename hackish_external_use <Type>::type>
    {
      static  const bool  value = true;
    };


    template <typename First, typename Second>
    struct hackish_external_use
      <std::pair <const First, Second>,
       typename impl::enable_if <supports_external_use <First>::value
                                 && !supports_external_use <std::pair <const First,
                                                                       Second> >::value>
       ::type>
    {
      typedef  std::pair <const First, Second>            type;
      typedef  typename external_use <First>::value_type  value_type;

      static  const value_type&
      get (const type& pair)
      {
        return external_use <First>::get (pair.first);
      }

      static  void
      set (type& pair, const value_type& value)
      {
        external_use <First>::set (const_cast <First&> (pair.first), value);
      }
    };

  }

}


#endif  // Multi-inclusion guard.


// Local variables:
// mode: c++
// c-basic-offset: 2
// indent-tabs-mode: nil
// fill-column: 90
// End:
