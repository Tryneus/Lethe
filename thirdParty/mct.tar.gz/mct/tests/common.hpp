// Copyright (c) 2009, 2010 Paul Pogonyshev.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.


#ifndef MCT_TESTS_COMMON_HPP
#define MCT_TESTS_COMMON_HPP


#include "tests/config.hpp"

#undef  MCT_ENABLE_DEBUGGING
#define MCT_ENABLE_DEBUGGING    1
#undef  MCT_CHECK_PRECONDITIONS
#define MCT_CHECK_PRECONDITIONS 1

// By default, MCT_CHECK_PRECONDITIONS disables iterators that don't refer to their table.
// However, in tests we want such iterators when possible, simply to make sure they work
// properly.
#undef  MCT_USE_EFFICIENT_ITERATORS
#define MCT_USE_EFFICIENT_ITERATORS     1

#include <mct/hash-map.hpp>
#include <mct/hash-set.hpp>

#include <algorithm>
#include <map>
#include <ostream>
#include <set>
#include <utility>
#include <vector>

#if MCT_CXX0X_SUPPORTED
# include <initializer_list>
#endif

#include <boost/foreach.hpp>
#include <boost/test/unit_test.hpp>


using namespace mct;

using namespace std;
namespace mpl = boost::mpl;


template <typename range_type>
size_t
range_size (const range_type& range)
{  return range.size ();  }

template <typename type, size_t n>
size_t
range_size (type (& array) [n])
{  return n;  }

template <typename range_type>
typename range_type::const_iterator
range_begin (const range_type& range)
{  return range.begin ();  }

template <typename type, size_t n>
type*
range_begin (type (& array) [n])
{  return array;  }

template <typename range_type>
typename range_type::const_iterator
range_end (const range_type& range)
{  return range.end ();  }

template <typename type, size_t n>
type*
range_end (type (& array) [n])
{  return array + n;  }

#define RANGE(range)            range_begin (range), range_end (range)


#define foreach                 BOOST_FOREACH
#define reverse_foreach         BOOST_REVERSE_FOREACH


// E.g. G++ 4.1 has 'long long' type, but no hash function specialization for it.
#if MCT_HAVE_LONG_LONG && !MCT_HAVE_LONG_LONG_HASH_SPECIALIZATION

MCT_HASH_NAMESPACE_ENTER
template <>
struct hash <unsigned long long>
{
  size_t
  operator() (unsigned long long value) const
  {
    return static_cast <size_t> (value);
  }
};
MCT_HASH_NAMESPACE_LEAVE

#endif


// Saves typing.
template <typename Container, typename type>
inline  bool
contains (const Container& container, const type& value)
{
  return container.find (value) != container.end ();
}


template <typename Map>
static  vector <typename Map::key_type>
keys_of (const Map& map)
{
  vector <typename Map::key_type>  keys;
  foreach (const typename Map::value_type& value, map)
    keys.push_back (value.first);

  return keys;
}


template <typename InputIterator>
ostream&
print_range (ostream& stream, const char* delimiters, InputIterator begin, InputIterator end)
{
  stream << delimiters[0];
  if (begin != end)
    stream << ' ';

  bool first = true;
  for (; begin != end; ++begin)
    {
      if (first)
        first = false;
      else
        stream << ", ";

      stream << *begin;
    }

  if (!first)
    stream << ' ';
  stream << delimiters[1];

  return stream;
}

template <typename InputIterator>
ostream&
print_map_range (ostream& stream, const char* delimiters, InputIterator begin, InputIterator end)
{
  stream << delimiters[0];
  if (begin != end)
    stream << ' ';

  bool first = true;
  for (; begin != end; ++begin)
    {
      if (first)
        first = false;
      else
        stream << ", ";

      stream << begin->first << ": " << begin->second;
    }

  if (!first)
    stream << ' ';
  stream << delimiters[1];

  return stream;
}


template <typename type>
vector <type>
create_vector (type (* generator) (int), int stop, int start = 0)
{
  vector <type>  result;

  if (stop > start)
    {
      result.reserve (stop - start);
      for (int k = start; k < stop; ++k)
        result.push_back (generator (k));
    }

  return result;
}


namespace mct
{

  namespace impl
  {

    template <typename Bucket>
    ostream&
    operator<< (ostream& stream, const hash_table_const_iterator <Bucket>& iter)
    {
      stream << "[iterator: " << &(*iter) << "]";
      return stream;
    }

  }

}


namespace std
{

  template <typename type>
  ostream&
  operator<< (ostream& stream, const vector <type>& array)
  {
    return print_range (stream, "[]", array.begin (), array.end ());
  }

}


// This one can be used to test if item destructor is called when it should be.  In
// addition, it has fancy size (3 bytes normally) fancy comparator and fancy hash
// function.
struct foo
{
  static  size_t  num_alive;

  unsigned char  byte1;
  unsigned char  byte2;
  unsigned char  byte3;

  explicit
  foo (unsigned char byte1 = 0, unsigned char byte2 = 0, unsigned char byte3 = 0)
    : byte1 (byte1),
      byte2 (byte2),
      byte3 (byte3)
  {
    ++num_alive;
  }

  foo (const foo& that)
    : byte1 (that.byte1),
      byte2 (that.byte2),
      byte3 (that.byte3)
  {
    ++num_alive;
  }

  ~foo ()
  {
    --num_alive;
  }
};


inline  bool
operator== (const foo& foo1, const foo& foo2)
{
  return (min    (foo1.byte1, foo1.byte2) == min (foo2.byte1, foo2.byte2)
          && max (foo1.byte1, foo1.byte2) == max (foo2.byte1, foo2.byte2)
          && foo1.byte3 == foo2.byte3);
}


MCT_HASH_NAMESPACE_ENTER
template <>
struct hash <foo>
{
  size_t
  operator() (const foo& _foo) const
  {
    return min (_foo.byte1, _foo.byte2) + 557 * (_foo.byte3 & 0x9b);
  }
};
MCT_HASH_NAMESPACE_LEAVE


inline  ostream&
operator<< (ostream& stream, const foo& _foo)
{
  stream << "("
         << static_cast <unsigned int> (_foo.byte1) << ", "
         << static_cast <unsigned int> (_foo.byte2) << ", "
         << static_cast <unsigned int> (_foo.byte3) << ")";
  return stream;
}


// This type is aimed at catching a specific bug discovered after 0.9.5 when compiling
// with GCC -O2 or -O3.
struct bar
{
  int  value : 16;

  explicit
  bar (int value = 0)
    : value (value)
  { }
};


inline  bool
operator== (const bar& bar1, const bar& bar2)
{
  return bar1.value == bar2.value;
}


MCT_HASH_NAMESPACE_ENTER
template <>
struct hash <bar> : public hash <int>
{
  size_t
  operator() (const bar& _bar) const
  {
    return hash <int>::operator() (_bar.value);
  }
};
MCT_HASH_NAMESPACE_LEAVE


inline  ostream&
operator<< (ostream& stream, const bar& _bar)
{
  stream << '[' << _bar.value << ']';
  return stream;
}


// Structure to test optional intrusion support introduced in 1.1.3.
struct ham
{
  int   value_int;
  char  value_char;
  char  _extern_use_field;

  explicit
  ham (int value_int = 0, char value_char = 0)
    : value_int  (value_int),
      value_char (value_char)
  { }
};


inline  bool
operator== (const ham& ham1, const ham& ham2)
{
  return ham1.value_int == ham2.value_int && ham1.value_char == ham2.value_char;
}


MCT_HASH_NAMESPACE_ENTER
template <>
struct hash <ham> : hash <int>, hash <char>
{
  size_t
  operator() (const ham& _ham) const
  {
    return hash <int>::operator() (_ham.value_int) ^ hash <char>::operator() (_ham.value_char);
  }
};
MCT_HASH_NAMESPACE_LEAVE


inline  ostream&
operator<< (ostream& stream, const ham& _ham)
{
  stream << '[' << _ham.value_int << ", " << +_ham.value_char << ']';
  return stream;
}


namespace mct
{
  template <>
  struct external_use <ham> : extern_use_field <ham, char, &ham::_extern_use_field>
  { };
}


struct int_wrapper
{
  // Not really needed.  Only used to make the type not have a trivial destructor.
  static  size_t  num_destroyed;

  int  value;

  explicit
  int_wrapper (int value = 0)
  {  this->value = value;  }

  ~int_wrapper ()
  {  ++num_destroyed;  }

  static  int_wrapper
  wrap (int value)
  {  return int_wrapper (value);  }
};


inline  bool
operator== (const int_wrapper& wrapper1, const int_wrapper& wrapper2)
{
  return wrapper1.value == wrapper2.value;
}


MCT_HASH_NAMESPACE_ENTER
template <>
struct hash <int_wrapper> : public hash <int>
{
  size_t
  operator() (const int_wrapper& wrapper) const
  {
    return hash <int>::operator() (wrapper.value);
  }
};
MCT_HASH_NAMESPACE_LEAVE


inline  ostream&
operator<< (ostream& stream, const int_wrapper& wrapper)
{
  stream << '[' << wrapper.value << ']';
  return stream;
}


struct expected_exception : public std::exception
{
  virtual  const char*
  what () const throw ()
  {  return "an expected exception";  }

  static  void
  maybe_throw (int& countdown)
  {
    if (countdown > 0)
      --countdown;
    else if (countdown == 0)
      throw expected_exception ();
  }
};


template <int& countdown>
class countdown_setter
{
  const int  _revert_to;

public:

  countdown_setter (int value = 0)
    : _revert_to (countdown)
  {  countdown = value;  }

  ~countdown_setter ()
  {  countdown = _revert_to;  }
};


struct throws_on_copy : public int_wrapper
{
  static  int  countdown;

  typedef  countdown_setter <countdown>  enabler;

  explicit
  throws_on_copy (int value = 0)
    : int_wrapper (value)
  { }

  throws_on_copy (const throws_on_copy& that)
    : int_wrapper (that)
  {
    expected_exception::maybe_throw (countdown);
  }
};


MCT_HASH_NAMESPACE_ENTER
template <>
struct hash <throws_on_copy> : public hash <int_wrapper>
{ };
MCT_HASH_NAMESPACE_LEAVE


struct throws_in_comparator : public int_wrapper
{
  static  int  countdown;

  typedef  countdown_setter <countdown>  enabler;

  explicit
  throws_in_comparator (int value = 0)
    : int_wrapper (value)
  { }
};


inline  bool
operator== (const throws_in_comparator& wrapper1, const throws_in_comparator& wrapper2)
{
  expected_exception::maybe_throw (throws_in_comparator::countdown);
  return wrapper1.value == wrapper2.value;
}


MCT_HASH_NAMESPACE_ENTER
template <>
struct hash <throws_in_comparator> : public hash <int_wrapper>
{ };
MCT_HASH_NAMESPACE_LEAVE


struct throws_in_hasher : public int_wrapper
{
  static  int  countdown;

  typedef  countdown_setter <countdown>  enabler;

  explicit
  throws_in_hasher (int value = 0)
    : int_wrapper (value)
  { }
};


MCT_HASH_NAMESPACE_ENTER
template <>
struct hash <throws_in_hasher> : public hash <int_wrapper>
{
  size_t
  operator() (const int_wrapper& wrapper) const
  {
    expected_exception::maybe_throw (throws_in_hasher::countdown);
    return hash <int>::operator() (wrapper.value);
  }
};
MCT_HASH_NAMESPACE_LEAVE


#if MCT_CXX0X_SUPPORTED

struct must_not_be_copied : public int_wrapper
{
  explicit
  must_not_be_copied (int value = 0)
    : int_wrapper (value)
  { }

  must_not_be_copied (const must_not_be_copied& that)
  {
    throw logic_error ("copy constructor used where it mustn't be");
  }

  must_not_be_copied (must_not_be_copied&& that)
    : int_wrapper (that)
  { }
};


MCT_HASH_NAMESPACE_ENTER
template <>
struct hash <must_not_be_copied> : public hash <int_wrapper>
{ };
MCT_HASH_NAMESPACE_LEAVE


struct must_not_be_moved : public int_wrapper
{
  explicit
  must_not_be_moved (int value = 0)
    : int_wrapper (value)
  { }

  must_not_be_moved (const must_not_be_moved& that)
    : int_wrapper (that)
  { }

  must_not_be_moved (must_not_be_moved&& that)
  {
    throw logic_error ("move constructor used where it mustn't be");
  }
};


MCT_HASH_NAMESPACE_ENTER
template <>
struct hash <must_not_be_moved> : public hash <int_wrapper>
{ };
MCT_HASH_NAMESPACE_LEAVE

#endif  // MCT_CXX0X_SUPPORTED


#if MCT_CXX0X_SUPPORTED


// 'type' below should be a subclass of 'int_wrapper' or something similar.

#define INITIALIZERS_0_50(type)                                 \
  { type ( 0), type ( 1), type ( 2), type ( 3), type ( 4),      \
    type ( 5), type ( 6), type ( 7), type ( 8), type ( 9),      \
    type (10), type (11), type (12), type (13), type (14),      \
    type (15), type (16), type (17), type (18), type (19),      \
    type (20), type (21), type (22), type (23), type (24),      \
    type (25), type (26), type (27), type (28), type (29),      \
    type (30), type (31), type (32), type (33), type (34),      \
    type (35), type (36), type (37), type (38), type (39),      \
    type (40), type (41), type (42), type (43), type (44),      \
    type (45), type (46), type (47), type (48), type (49) }

#define INITIALIZERS_40_60(type)                                \
  { type (40), type (41), type (42), type (43), type (44),      \
    type (45), type (46), type (47), type (48), type (49),      \
    type (50), type (51), type (52), type (53), type (54),      \
    type (55), type (56), type (57), type (58), type (59) }


#endif  // MCT_CXX0X_SUPPORTED


class leak_test_data
{
  static  int  num_allocators;

protected:

  static  set <pair <const type_info*, pair <void*, size_t> > >  allocated_chunks;
  static  set <pair <const type_info*, void*> >                  constructed_objects;

  static  void
  new_allocator ()
  {  ++num_allocators;  }

  static  void  delete_allocator ();
};


template <typename Wrapped>
struct leak_test_allocator : public Wrapped, protected leak_test_data
{
  typedef  Wrapped  base_type;

  typedef  typename base_type::value_type  value_type;
  typedef  typename base_type::pointer     pointer;
  typedef  typename base_type::size_type   size_type;


  template <typename type>
  struct rebind
  {
    typedef  leak_test_allocator <typename base_type::template rebind <type>::other>  other;
  };


  leak_test_allocator ()
  {
    leak_test_data::new_allocator ();
  }

  explicit
  leak_test_allocator (const base_type& base)
    : base_type (base)
  {
    leak_test_data::new_allocator ();
  }

  leak_test_allocator (const leak_test_allocator& that)
    : base_type (that)
  {
    leak_test_data::new_allocator ();
  }

  template <typename base>
  leak_test_allocator (const leak_test_allocator <base>& that)
    : base_type (that)
  {
    leak_test_data::new_allocator ();
  }

  ~leak_test_allocator ()
  {
    leak_test_data::delete_allocator ();
  }


  pointer
  allocate (size_type size)
  {
    // Tests are not supposed to cause huge allocations and this check might prevent a
    // buggy implementation to go out of hands.
    if (size > 1000000)
      throw std::bad_alloc ();

    const pointer  chunk = base_type::allocate (size);

    allocated_chunks.insert (make_pair (&typeid (chunk), make_pair (chunk, size)));
    return chunk;
  }

  void
  deallocate (pointer chunk, size_type size)
  {
    allocated_chunks.erase (make_pair (&typeid (chunk), make_pair (chunk, size)));
    base_type::deallocate (chunk, size);
  }

  void
  construct (pointer element, const value_type& value)
  {
    base_type::construct (element, value);
    if (!impl::has_trivial_destructor <value_type>::value)
      constructed_objects.insert (make_pair (&typeid (element), element));
  }

#if MCT_CXX0X_SUPPORTED

  void
  construct (pointer element, value_type&& value)
  {
    base_type::construct (element, forward <value_type> (value));
    if (!impl::has_trivial_destructor <value_type>::value)
      constructed_objects.insert (make_pair (&typeid (element), element));
  }

#endif  // MCT_CXX0X_SUPPORTED

  void
  destroy (pointer element)
  {
    if (!impl::has_trivial_destructor <value_type>::value)
      {
        if (!constructed_objects.erase (make_pair (&typeid (element), element)))
          throw logic_error ("destroying an object that was never (successfully) constructed");
      }

    base_type::destroy (element);
  }
};


struct int_hasher_1
{
  size_t
  operator() (int value) const
  {  return value + 3;;  }
};

struct int_hasher_special
{
  // Intentionally 'bad' hash.
  size_t
  operator() (int value) const
  {  return value & 0x3;  }
};

struct int_comparator_special
{
  bool
  operator() (int a, int b) const
  {  return (a & 0x7) == (b & 0x7);  }
};

struct string_hasher_1 : public MCT_HASH_NAMESPACE::hash <string>
{
  size_t
  operator() (const string& value) const
  {
    return MCT_HASH_NAMESPACE::hash <string>::operator() (value) ^ 1337;
  }
};

#if MCT_HAVE_LONG_LONG

struct unsigned_long_long_hasher
{
  size_t
  operator() (unsigned long long value) const
  {
    return (value & 0xffffffffu) + (value >> 32);
  }
};

#endif  // MCT_HAVE_LONG_LONG


template <typename key_type, typename value_type>
struct key_extractor
{
  static  const key_type&
  extract (const value_type& value)
  {  return value.first;  }
};

template <typename key_type>
struct key_extractor <key_type, key_type>
{
  static  const key_type&
  extract (const key_type& value)
  {  return value;  }
};


template <typename Container, typename Initializer>
void
assert_identical_order (const Container& container, const Initializer& initializer)
{
  typedef  typename Container::key_type    key_type;
  typedef  typename Container::value_type  value_type;
  typedef  map <int, key_type>             order_map;

  vector <key_type>    actual_order;
  vector <key_type>    expected_order;
  order_map            order;

  foreach (const value_type& value, container)
    {
      const key_type&  key = key_extractor <key_type, value_type>::extract (value);
      actual_order.push_back (key);

      int  index = 0;
      foreach (const key_type& candidate, initializer)
        {
          if (container.key_eq () (key, candidate))
            {
              order.insert (make_pair (index, key));
              break;
            }

          ++index;
        }
    }

  foreach (const typename order_map::value_type& entry, order)
    expected_order.push_back (entry.second);

  BOOST_CHECK_EQUAL (actual_order, expected_order);
}


template <typename type>
struct Data;


template <>
struct Data <int>
{
  static  const vector <int>&
  values1 ()
  {
    static  const int  as_array[] = { 10, -6, 1, 3 };
    static  const vector <int>  as_vector (RANGE (as_array));

    return as_vector;
  }

  static  const vector <int>&
  values2 ()
  {
    static  const int  as_array[] = { 0, -3, 10, 8, 12, 1, -9 };
    static  const vector <int>  as_vector (RANGE (as_array));

    return as_vector;
  }

  static  int
  generate (int iteration)
  {  return iteration;  }
};


template <>
struct Data <string>
{
  static  const vector <string>&
  values1 ()
  {
    static  const string  as_array[] = { "mon", "tue", "wed", "thu", "fri", "sat", "sun" };
    static  const vector <string>  as_vector (RANGE (as_array));

    return as_vector;
  }

  static  const vector <string>&
  values2 ()
  {
    static  const string  as_array[] = { "jan", "feb", "mar", "apr", "may", "etc" };
    static  const vector <string>  as_vector (RANGE (as_array));

    return as_vector;
  }

  static  string
  generate (int iteration)
  {
    string  result;
    result.resize (iteration, '*');
    return result;
  }
};


template <>
struct Data <foo>
{
  static  const vector <foo>&
  values1 ()
  {
    static  const foo  as_array[]
      = { foo (0, 15, 3), foo (3, 8, 1), foo (9, 2, 2), foo (6, 0, 0), foo (1, 0, 7) };
    static  const vector <foo>  as_vector (RANGE (as_array));

    return as_vector;
  }

  static  const vector <foo>&
  values2 ()
  {
    static  const foo  as_array[]
      = { foo (1, 2, 1), foo (2, 8, 17), foo (3, 3, 3), foo (19, 0, 2) };
    static  const vector <foo>  as_vector (RANGE (as_array));

    return as_vector;
  }

  static  foo
  generate (int iteration)
  {
    unsigned int   first = (iteration / 0x100);
    unsigned char  byte3 = (iteration & 0xff);
    unsigned int   byte1 = 0;

    while (first > byte1)
      first -= ++byte1;

    unsigned int  byte2 = first;

    if (byte1 >= 0x100 || byte2 >= 0x100)
      throw logic_error ("iteration is too large");

    return foo (byte1, byte2, byte3);
  }
};


template <>
struct Data <bar>
{
  static  const vector <bar>&
  values1 ()
  {
    static  const bar  as_array[] = { bar (42), bar (0), bar (3), bar (-3) };
    static  const vector <bar>  as_vector (RANGE (as_array));

    return as_vector;
  }

  static  const vector <bar>&
  values2 ()
  {
    static  const bar  as_array[] = { bar (7), bar (13), bar (1), bar (0), bar (88), bar (14) };
    static  const vector <bar>  as_vector (RANGE (as_array));

    return as_vector;
  }

  static  bar
  generate (int iteration)
  {  return bar (iteration);  }
};


template <>
struct Data <ham>
{
  static  const vector <ham>&
  values1 ()
  {
    static  const ham  as_array[]
      = { ham (113, 'x'), ham (0, '^'), ham (0, '\0'), ham (-37, 'x') };
    static  const vector <ham>  as_vector (RANGE (as_array));

    return as_vector;
  }

  static  const vector <ham>&
  values2 ()
  {
    static  const ham  as_array[]
      = { ham (66, '0'), ham (-4, '7'), ham (91, '~'), ham (91, '/'), ham (61, '/'),
          ham (812, '7') };
    static  const vector <ham>  as_vector (RANGE (as_array));

    return as_vector;
  }

  static  ham
  generate (int iteration)
  {  return ham (iteration, iteration);  }
};


#if MCT_HAVE_LONG_LONG

template <>
struct Data <unsigned long long>
{
  static  const vector <unsigned long long>&
  values1 ()
  {
    static  const unsigned long long  as_array[] = { 10, -6, 1, 3 };
    static  const vector <unsigned long long>  as_vector (RANGE (as_array));

    return as_vector;
  }

  static  const vector <unsigned long long>&
  values2 ()
  {
    static  const unsigned long long  as_array[] = { 0, -3, 10, 8, 12, 1, -9 };
    static  const vector <unsigned long long>  as_vector (RANGE (as_array));

    return as_vector;
  }

  static  unsigned long long
  generate (int iteration)
  {  return iteration;  }
};

#endif  // MCT_HAVE_LONG_LONG


template <typename key_type, typename mapped_type>
struct Data <pair <key_type, mapped_type> >
{
  static  const vector <pair <key_type, mapped_type> >&
  values1 ()
  {
    static  const vector <pair <key_type, mapped_type> >  as_vector
      (combine (Data <key_type>::values1 (), Data <mapped_type>::values1 ()));

    return as_vector;
  }

  static  const vector <pair <key_type, mapped_type> >&
  values2 ()
  {
    static  const vector <pair <key_type, mapped_type> >  as_vector
      (combine (Data <key_type>::values2 (), Data <mapped_type>::values2 ()));

    return as_vector;
  }

  static  const vector <key_type>&
  keys1 ()
  {
    static  const vector <key_type>  as_vector
      (truncate (Data <key_type>::values1 (), Data <mapped_type>::values1 ()));

    return as_vector;
  }

  static  const vector <key_type>&
  keys2 ()
  {
    static  const vector <key_type>  as_vector
      (truncate (Data <key_type>::values2 (), Data <mapped_type>::values2 ()));

    return as_vector;
  }

  static  pair <key_type, mapped_type>
  generate (int iteration)
  {
    return make_pair (Data <key_type>   ::generate (iteration),
                      Data <mapped_type>::generate (iteration));
  }


private:

  static  const vector <pair <key_type, mapped_type> >
  combine (const vector <key_type>& left, const vector <mapped_type>& right)
  {
    vector <pair <key_type, mapped_type> >  result;

    for (size_t k = 0, size = min (left.size (), right.size ()); k < size; ++k)
      result.push_back (make_pair (left[k], right[k]));

    return result;
  }

  static  const vector <key_type>
  truncate (const vector <key_type>& left, const vector <mapped_type>& right)
  {
    vector <key_type>  result (left);

    result.resize (min (left.size (), right.size ()));
    return result;
  }
};


#endif  // Multi-inclusion guard.


// Local variables:
// mode: c++
// c-basic-offset: 2
// indent-tabs-mode: nil
// fill-column: 90
// End:
