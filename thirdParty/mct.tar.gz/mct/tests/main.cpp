// Copyright (c) 2009, 2010 Paul Pogonyshev.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.


#define BOOST_AUTO_TEST_MAIN
#include "tests/common.hpp"


size_t  foo                 ::num_alive     =  0;
size_t  int_wrapper         ::num_destroyed =  0;
int     throws_on_copy      ::countdown     = -1;
int     throws_in_comparator::countdown     = -1;
int     throws_in_hasher    ::countdown     = -1;


int                                                    leak_test_data::num_allocators = 0;
set <pair <const type_info*, pair <void*, size_t> > >  leak_test_data::allocated_chunks;
set <pair <const type_info*, void*> >                  leak_test_data::constructed_objects;


void
leak_test_data::delete_allocator ()
{
  if (!--num_allocators)
    {
      BOOST_CHECK_EQUAL (allocated_chunks.size (), 0u);
      BOOST_CHECK_EQUAL (constructed_objects.size (), 0u);

      allocated_chunks.clear ();
      constructed_objects.clear ();
    }
}


// Local variables:
// mode: c++
// c-basic-offset: 2
// indent-tabs-mode: nil
// fill-column: 90
// End:
