// Copyright (c) 2010 Paul Pogonyshev.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.


#ifdef MCT_TESTS_COMMON_HPP
# error common.hpp must not be included before map-common.hpp
#endif


#ifndef MCT_TESTS_MAP_COMMON_HPP
#define MCT_TESTS_MAP_COMMON_HPP


#include "tests/common.hpp"

#include <boost/test/unit_test.hpp>

#if HAVE_UNORDERED_MAP
# include <unordered_map>
using std::unordered_map;

#elif HAVE_TR1_UNORDERED_MAP
# include <tr1/unordered_map>
using std::tr1::unordered_map;

#elif HAVE_BOOST_UNORDERED_MAP_HPP
# include <boost/unordered_map.hpp>
using boost::unordered_map;
#endif


namespace mct
{

#define TEST_MAP_OUTPUT(tested_map_type)                                                        \
  template <typename Key, typename Mapped, typename Hash, typename Equal, typename Allocator,   \
            bool keep_hashes>                                                                   \
  ostream&                                                                                      \
  operator<< (ostream& stream,                                                                  \
              const tested_map_type <Key, Mapped, Hash, Equal, Allocator, keep_hashes>& map)    \
  {                                                                                             \
    return print_map_range (stream, "{}", map.begin (), map.end ());                            \
  }

  TEST_MAP_OUTPUT (closed_hash_map)
  TEST_MAP_OUTPUT (linked_hash_map)
  TEST_MAP_OUTPUT (forward_hash_map)

}


namespace std
{

  template <typename Key, typename Mapped, typename Hash, typename Equal, typename Allocator>
  ostream&
  operator<< (ostream& stream, const unordered_map <Key, Mapped, Hash, Equal, Allocator>& map)
  {
    return print_map_range (stream, "{}", map.begin (), map.end ());
  }

}


#define TEST_MAP_COMPARISON(tested_map_type)                                                    \
  template <typename Key, typename Mapped, typename Hash, typename Equal, typename Allocator,   \
            bool keep_hashes>                                                                   \
  bool                                                                                          \
  operator== (const tested_map_type <Key, Mapped, Hash, Equal, leak_test_allocator <Allocator>, \
                                     keep_hashes>& tested_map,                                  \
              const unordered_map <Key, Mapped, Hash, Equal, Allocator>& robust_map)            \
  {                                                                                             \
    if (tested_map.size () != robust_map.size ())                                               \
      return false;                                                                             \
    typedef  pair <const Key, Mapped>  value_type;                                              \
    foreach (const value_type& association, robust_map)                                         \
      {                                                                                         \
        typename tested_map_type <Key, Mapped, Hash, Equal, leak_test_allocator <Allocator>,    \
                                  keep_hashes>::const_iterator                                  \
          match = tested_map.find (association.first);                                          \
        if (match == tested_map.end () || !(match->second == association.second))               \
          return false;                                                                         \
      }                                                                                         \
    return true;                                                                                \
  }

TEST_MAP_COMPARISON (closed_hash_map)
TEST_MAP_COMPARISON (linked_hash_map)
TEST_MAP_COMPARISON (forward_hash_map)


template <typename Implementation>
class test_map_base : public Implementation
{
public:

  typedef  Implementation                                implementation_type;

  // Make the type public for the purpose of testing.
  typedef  typename implementation_type::bucket_type     bucket_type;

  typedef  typename implementation_type::key_type        key_type;
  typedef  typename implementation_type::mapped_type     mapped_type;
  typedef  typename implementation_type::value_type      value_type;
  typedef  typename implementation_type::iterator        iterator;
  typedef  typename implementation_type::const_iterator  const_iterator;
  typedef  typename implementation_type::hasher          hasher;
  typedef  typename implementation_type::key_equal       key_equal;
  typedef  typename implementation_type::allocator_type  allocator_type;
  typedef  typename allocator_type::base_type            allocator_base;

protected:

  // Note that we don't use leak test allocator for the map we check against.
  typedef  unordered_map <key_type, mapped_type, hasher, key_equal, allocator_base>  robust_type;


  robust_type  _valid;


public:

  explicit
  test_map_base (size_t                num_buckets = 0,
                 const hasher&         hash        = hasher (),
                 const key_equal&      equal       = key_equal (),
                 const allocator_type& allocator   = allocator_type ())
    : implementation_type (num_buckets, hash, equal, allocator),
      _valid              (num_buckets, hash, equal, allocator)
  {
    validate ();
  }

# if MCT_CXX0X_SUPPORTED

  test_map_base (test_map_base&& that)
    : implementation_type (move (that)),
      _valid              (that._valid)
  { }

  test_map_base (initializer_list <value_type> initializer,
                 size_t                num_buckets = 0,
                 const hasher&         hash        = hasher (),
                 const key_equal&      equal       = key_equal (),
                 const allocator_type& allocator   = allocator_type ())
    : implementation_type (initializer, num_buckets, hash, equal, allocator),
      _valid              (num_buckets, hash, equal, allocator)
  {
    // Not requiring that the robust implementation has this constructor.
    _valid.insert (initializer.begin (), initializer.end ());
    validate ();
  }

# endif  // MCT_CXX0X_SUPPORTED

  template <typename InputIterator>
  test_map_base (InputIterator begin, InputIterator end,
                 size_t                num_buckets = 0,
                 const hasher&         hash        = hasher (),
                 const key_equal&      equal       = key_equal (),
                 const allocator_type& allocator   = allocator_type ())
    : implementation_type (begin, end, num_buckets, hash, equal, allocator),
      _valid              (begin, end, num_buckets, hash, equal, allocator)
  {
    validate ();
  }

  ~test_map_base ()
  {
    if (this->_data.buckets)
      validate ();
  }


  test_map_base&
  operator= (const test_map_base& that)
  {
    implementation_type::operator= (that);
    this->_valid = that._valid;
    validate ();
    return *this;
  }

# if MCT_CXX0X_SUPPORTED

  test_map_base&
  operator= (test_map_base&& that)
  {
    implementation_type::operator= (move (that));
    this->_valid = that._valid;
    validate ();
    return *this;
  }

  test_map_base&
  operator= (initializer_list <value_type> initializer)
  {
    implementation_type::operator= (initializer);
    _valid.clear ();
    _valid.insert (initializer.begin (), initializer.end ());
    validate ();
    return *this;
  }

# endif  // MCT_CXX0X_SUPPORTED


  pair <iterator, bool>
  insert (const value_type& value)
  {
    const pair <iterator, bool>  result (implementation_type::insert (value));
    _valid.insert (value);
    validate ();
    return result;
  }

  iterator
  insert (const_iterator hint, const value_type& value)
  {
    const iterator  result (implementation_type::insert (hint, value));
    _valid.insert (_valid.end (), value);
    validate ();
    return result;
  }

  template <typename InputIterator>
  void
  insert (InputIterator begin, InputIterator end)
  {
    implementation_type::insert (begin, end);
    _valid.insert (begin, end);
    validate ();
  }


  void
  subscript (const key_type& key, const mapped_type& mapped)
  {
    this-> operator[] (key) = mapped;
    _valid.operator[] (key) = mapped;
    validate ();
  }


  void
  clear ()
  {
    implementation_type::clear ();
    _valid.clear ();
    validate ();
  }


  void
  swap (test_map_base& that)
  {
    implementation_type::swap (that);
    _valid.swap (that._valid);
    validate ();
    that.validate ();
  }


  void
  rehash (size_t num_buckets)
  {
    implementation_type::rehash (num_buckets);
    validate ();
  }


  // Assigning directly to iterator is of course possible, but will break all further
  // validate() calls.  Subclass iterators sounds a bit too difficult to me.
  void
  assign_through_iterator (iterator position, mapped_type value)
  {
    BOOST_REQUIRE_EQUAL (position, this->find (position->first));
    position->second                      = value;
    _valid.find (position->first)->second = value;
    validate ();
  }


  void
  validate () const
  {
    implementation_type::validate_integrity ();
    BOOST_REQUIRE_EQUAL (*this, _valid);
  }
};


template <typename implementation_type, typename family = typename implementation_type::_family>
class test_map;


template <typename implementation_type>
class test_map <implementation_type, impl::closed_table_family>
  : public test_map_base <implementation_type>
{
  typedef  test_map_base <implementation_type>  base_type;

public:

  typedef  typename base_type::key_type         key_type;
  typedef  typename base_type::value_type       value_type;
  typedef  typename base_type::iterator         iterator;
  typedef  typename base_type::const_iterator   const_iterator;
  typedef  typename base_type::hasher           hasher;
  typedef  typename base_type::key_equal        key_equal;
  typedef  typename base_type::allocator_type   allocator_type;


public:

  explicit
  test_map (size_t                num_buckets = 0,
            const hasher&         hash        = hasher (),
            const key_equal&      equal       = key_equal (),
            const allocator_type& allocator   = allocator_type ())
    : base_type (num_buckets, hash, equal, allocator)
  { }

# if MCT_CXX0X_SUPPORTED

  test_map (test_map&& that)
    : base_type (move (that))
  { }

  test_map (initializer_list <value_type> initializer,
            size_t                num_buckets = 0,
            const hasher&         hash        = hasher (),
            const key_equal&      equal       = key_equal (),
            const allocator_type& allocator   = allocator_type ())
    : base_type (initializer, num_buckets, hash, equal, allocator)
  { }

# endif  // MCT_CXX0X_SUPPORTED

  template <typename InputIterator>
  test_map (InputIterator begin, InputIterator end,
            size_t                num_buckets = 0,
            const hasher&         hash        = hasher (),
            const key_equal&      equal       = key_equal (),
            const allocator_type& allocator   = allocator_type ())
    : base_type (begin, end, num_buckets, hash, equal, allocator)
  { }


  bool
  erase (const key_type& key)
  {
    const bool  result = implementation_type::erase (key);
    BOOST_REQUIRE_EQUAL (result, this->_valid.erase (key));
    this->validate ();
    return result;
  }

  iterator
  erase (const_iterator position)
  {
    this->_valid.erase (position->first);
    const iterator  result = implementation_type::erase (position);
    this->validate ();
    return result;
  }

  iterator
  erase (const_iterator first, const_iterator last)
  {
    // Order is not required to be the same; emulate.
    for (const_iterator scan = first; scan != last; ++scan)
      this->_valid.erase (scan->first);

    const iterator  result = implementation_type::erase (first, last);
    this->validate ();
    return result;
  }
};


template <typename implementation_type>
class test_map <implementation_type, impl::linked_table_family>
  : public test_map <implementation_type, impl::closed_table_family>
{
  typedef  test_map <implementation_type, impl::closed_table_family>  base_type;

public:

  typedef  typename base_type::key_type         key_type;
  typedef  typename base_type::value_type       value_type;
  typedef  typename base_type::iterator         iterator;
  typedef  typename base_type::const_iterator   const_iterator;
  typedef  typename base_type::hasher           hasher;
  typedef  typename base_type::key_equal        key_equal;
  typedef  typename base_type::allocator_type   allocator_type;


public:

  explicit
  test_map (size_t                num_buckets = 0,
            const hasher&         hash        = hasher (),
            const key_equal&      equal       = key_equal (),
            const allocator_type& allocator   = allocator_type ())
    : base_type (num_buckets, hash, equal, allocator)
  { }

# if MCT_CXX0X_SUPPORTED

  test_map (test_map&& that)
    : base_type (move (that))
  { }

  test_map (initializer_list <value_type> initializer,
            size_t                num_buckets = 0,
            const hasher&         hash        = hasher (),
            const key_equal&      equal       = key_equal (),
            const allocator_type& allocator   = allocator_type ())
    : base_type (initializer, num_buckets, hash, equal, allocator)
  { }

# endif  // MCT_CXX0X_SUPPORTED

  template <typename InputIterator>
  test_map (InputIterator begin, InputIterator end,
            size_t                num_buckets = 0,
            const hasher&         hash        = hasher (),
            const key_equal&      equal       = key_equal (),
            const allocator_type& allocator   = allocator_type ())
    : base_type (begin, end, num_buckets, hash, equal, allocator)
  { }


  void
  pop_front ()
  {
    this->_valid.erase (this->front ());
    implementation_type::pop_front ();
    this->validate ();
  }

  void
  pop_back ()
  {
    this->_valid.erase (this->back ());
    implementation_type::pop_back ();
    this->validate ();
  }
};


template <typename implementation_type>
class test_map <implementation_type, impl::forward_table_family>
  : public test_map_base <implementation_type>
{
  typedef  test_map_base <implementation_type>  base_type;

public:

  typedef  typename base_type::key_type         key_type;
  typedef  typename base_type::value_type       value_type;
  typedef  typename base_type::iterator         iterator;
  typedef  typename base_type::const_iterator   const_iterator;
  typedef  typename base_type::hasher           hasher;
  typedef  typename base_type::key_equal        key_equal;
  typedef  typename base_type::allocator_type   allocator_type;


public:

  explicit
  test_map (size_t                num_buckets = 0,
            const hasher&         hash        = hasher (),
            const key_equal&      equal       = key_equal (),
            const allocator_type& allocator   = allocator_type ())
    : base_type (num_buckets, hash, equal, allocator)
  { }

# if MCT_CXX0X_SUPPORTED

  test_map (test_map&& that)
    : base_type (move (that))
  { }

  test_map (initializer_list <value_type> initializer,
            size_t                num_buckets = 0,
            const hasher&         hash        = hasher (),
            const key_equal&      equal       = key_equal (),
            const allocator_type& allocator   = allocator_type ())
    : base_type (initializer, num_buckets, hash, equal, allocator)
  { }

# endif  // MCT_CXX0X_SUPPORTED

  template <typename InputIterator>
  test_map (InputIterator begin, InputIterator end,
            size_t                num_buckets = 0,
            const hasher&         hash        = hasher (),
            const key_equal&      equal       = key_equal (),
            const allocator_type& allocator   = allocator_type ())
    : base_type (begin, end, num_buckets, hash, equal, allocator)
  { }


  void
  pop_front ()
  {
    this->_valid.erase (this->front ());
    implementation_type::pop_front ();
    this->validate ();
  }


  void
  erase_after (const_iterator after)
  {
    const_iterator  position = after;
    this->_valid.erase (*++position);
    implementation_type::erase_after (after);
    this->validate ();
  }

  void
  erase_after (const_iterator after, const_iterator last)
  {
    // Order is not required to be the same; emulate.
    for (const_iterator scan = after; ++scan != last;)
      this->_valid.erase (*scan);

    implementation_type::erase_after (after, last);
    this->validate ();
  }
};


template <typename implementation_type, typename family>
inline  void
swap (test_map <implementation_type, family>& map1, test_map <implementation_type, family>& map2)
{
  map1.swap (map2);
}


struct Plain
{
  template <typename Key, typename Mapped,
            typename Hash    = MCT_HASH_NAMESPACE::hash <Key>,
            typename Equal   = equal_to <Key>,
            bool keep_hashes = false>
  struct resolve
  {
    typedef  closed_hash_map <Key, Mapped, Hash, Equal,
                              leak_test_allocator <allocator <pair <const Key, Mapped> > >,
                              keep_hashes>
             map_type;
  };

  static  const bool  normal = true;
  static  const bool  linked = false;
};


struct Linked
{
  template <typename Key, typename Mapped,
            typename Hash    = MCT_HASH_NAMESPACE::hash <Key>,
            typename Equal   = equal_to <Key>,
            bool keep_hashes = false>
  struct resolve
  {
    typedef  linked_hash_map <Key, Mapped, Hash, Equal,
                              leak_test_allocator <allocator <pair <const Key, Mapped> > >,
                              keep_hashes>
             map_type;
  };

  static  const bool  normal = true;
  static  const bool  linked = true;
};


struct Forward
{
  template <typename Key, typename Mapped,
            typename Hash    = MCT_HASH_NAMESPACE::hash <Key>,
            typename Equal   = equal_to <Key>,
            bool keep_hashes = false>
  struct resolve
  {
    typedef  forward_hash_map <Key, Mapped, Hash, Equal,
                               leak_test_allocator <allocator <pair <const Key, Mapped> > >,
                               keep_hashes>
             map_type;
  };

  static  const bool  normal = false;
  static  const bool  linked = true;
};


#endif  // Multi-inclusion guard.


// Local variables:
// mode: c++
// c-basic-offset: 2
// indent-tabs-mode: nil
// fill-column: 90
// End:
