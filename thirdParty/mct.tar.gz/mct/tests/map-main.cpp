// Copyright (c) 2010 Paul Pogonyshev.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.


#undef  MCT_SELF_VALIDATION
#define MCT_SELF_VALIDATION     1

#include "tests/map-common.hpp"
#include "tests/map-parameters.hpp"


BOOST_AUTO_TEST_SUITE (map_main)


BOOST_AUTO_TEST_CASE_TEMPLATE (test_range_constructor_1,
                               parameters, test_parameters)
{
  COMMON_TEST_SETUP;

  map_type  map (RANGE (value_data::values1 ()));
  if (linked)
    assert_identical_order (map, value_data::keys1 ());
}


#if MCT_CXX0X_SUPPORTED

BOOST_AUTO_TEST_CASE_TEMPLATE (test_initializer_constructor_1,
                               implementation, test_implementations)
{
  typedef  typename implementation::template resolve <int, string>::map_type  map_type;

  map_type  map1 { { 1, "foo" }, { 2, "bar" }, { 3, "baz" }, { 4, "ham" } };
  map_type  map2 { { 1, "foo" }, { 3, "bar" }, { 1, "baz" }, { 3, "ham" }, { 2, "spam" },
                   { 2, "egg" }, { 2, "bop" } };

  map_type  expected { { 1, "foo" }, { 3, "bar" }, { 2, "spam" } };
  BOOST_CHECK_EQUAL (map2, expected);

  if (implementation::linked)
    {
      assert_identical_order (map1, vector <int> { 1, 2, 3, 4 });
      assert_identical_order (map2, vector <int> { 1, 3, 1, 3, 2, 2, 2 });
    }
}

#endif  // MCT_CXX0X_SUPPORTED


BOOST_AUTO_TEST_CASE_TEMPLATE (test_find_1,
                               parameters, test_parameters)
{
  COMMON_TEST_SETUP;

  map_type  map (RANGE (value_data::values1 ()));

  foreach (const key_type& key, value_data::keys1 ())
    BOOST_CHECK (contains (map, key));

  foreach (const key_type& key, key_data::values2 ())
    {
      BOOST_CHECK_EQUAL (contains (map, key),
                         (find (RANGE (value_data::keys1 ()), key)
                          != range_end (value_data::keys1 ())));
    }
}


BOOST_AUTO_TEST_CASE_TEMPLATE (test_count_1,
                               parameters, test_parameters)
{
  COMMON_TEST_SETUP;

  map_type  map (RANGE (value_data::values1 ()));

  foreach (const key_type& key, value_data::keys1 ())
    BOOST_CHECK_EQUAL (map.count (key), 1u);

  foreach (const key_type& key, key_data::values2 ())
    {
      BOOST_CHECK_EQUAL (map.count (key),
                         ((find (RANGE (value_data::keys1 ()), key)
                           != range_end (value_data::keys1 ()))
                          ? 1u : 0u));
    }
}


BOOST_AUTO_TEST_CASE_TEMPLATE (test_equal_range_1,
                               parameters, test_parameters)
{
  COMMON_TEST_SETUP;

  map_type  map (RANGE (value_data::values1 ()));

  foreach (const key_type& key, value_data::keys1 ())
    {
      pair <const_iterator, const_iterator>  range (map.equal_range (key));
      BOOST_CHECK       (map.key_eq () (range.first->first, key));
      BOOST_CHECK_EQUAL (++range.first, range.second);
    }

  foreach (const key_type& key, key_data::values2 ())
    {
      pair <const_iterator, const_iterator>  range (map.equal_range (key));

      if (find (RANGE (value_data::keys1 ()), key) == range_end (value_data::keys1 ()))
        BOOST_CHECK_EQUAL (range.first, range.second);
      else
        {
          BOOST_CHECK       (map.key_eq () (range.first->first, key));
          BOOST_CHECK_EQUAL (++range.first, range.second);
        }
    }
}


BOOST_AUTO_TEST_CASE_TEMPLATE (test_insert_1,
                               parameters, test_parameters)
{
  COMMON_TEST_SETUP;

  map_type  map;
  foreach (const key_type& key, key_data::values1 ())
    map.insert (make_pair (key, mapped_type ()));
}

BOOST_AUTO_TEST_CASE_TEMPLATE (test_insert_range_1,
                               parameters, test_parameters)
{
  COMMON_TEST_SETUP;

  map_type  map;
  map.insert (RANGE (value_data::values1 ()));
}


#if MCT_CXX0X_SUPPORTED

BOOST_AUTO_TEST_CASE_TEMPLATE (test_insert_moving_1,
                               implementation, test_implementations)
{
  // Note that we use 'pair <const ..., ...>' in this test.  While inserting a pair
  // without constified first member works fine, this involves some hidden conversions and
  // those call copy or move constructors, thus making the test fail.  We only want to
  // test whether the containers themselves don't copy/move when they shouldn't, so the
  // usage is a little bit cumbersome.

  // FIXME: This part of the test is currently disabled, because it is not expected to
  //        pass.  The problem is that 'value_type' in a map is 'pair <const key_type,
  //        mapped_type>' and constness of the first field prevents move constructor from
  //        kicking in.  I guess it can be solved and eventually should be, but this is
  //        not very important.
  if (false)
  {
    typedef  typename implementation::template resolve <must_not_be_copied, int>::map_type
             map_type;

    // Make it large, so it never rehashes and thus copies elements.
    map_type  map1 (1000);

    for (int k = 0; k < 100; ++k)
      {
        map1.insert (pair <const must_not_be_copied, int> (must_not_be_copied (k), 0));
        map1.validate_integrity ();
      }

    map_type  map2 (1000);

    for (int k = 0; k < 100; ++k)
      {
        map2[must_not_be_copied (k)] = 0;
        map2.validate_integrity ();
      }
  }

  {
    typedef  typename implementation::template resolve <int, must_not_be_copied>::map_type
             map_type;

    map_type  map1 (1000);

    for (int k = 0; k < 100; ++k)
      {
        map1.insert (pair <const int, must_not_be_copied> (k, must_not_be_copied (k)));
        map1.validate_integrity ();
      }
  }

  {
    typedef  typename implementation::template resolve <must_not_be_moved, int>::map_type
             map_type;

    map_type  map1 (1000);

    for (int k = 0; k < 100; ++k)
      {
        must_not_be_moved                    key (k);
        pair <const must_not_be_moved, int>  value (key, 0);

        map1.insert (value);
        map1.validate_integrity ();
      }

    map_type  map2 (1000);

    for (int k = 0; k < 100; ++k)
      {
        must_not_be_moved  key (k);

        map2[key] = 0;
        map2.validate_integrity ();
      }
  }

  {
    typedef  typename implementation::template resolve <int, must_not_be_moved>::map_type
             map_type;

    map_type  map1 (1000);

    for (int k = 0; k < 100; ++k)
      {
        must_not_be_moved                    mapped (k);
        pair <const int, must_not_be_moved>  value (k, mapped);

        map1.insert (value);
        map1.validate_integrity ();
      }
  }
}

BOOST_AUTO_TEST_CASE_TEMPLATE (test_insert_initializers_1,
                               implementation, test_implementations)
{
  typedef  typename implementation::template resolve <int, string>::map_type  map_type;

  map_type  map { { 0, "foo" }, { 1, "bar" }, { 2, "baz" } };
  map.insert ({ { 3, "ham" }, { 4, "spam" }, { 5, "egg" } });

  vector <pair <int, string> >  expected_vector { { 0, "foo" }, { 1, "bar"  }, { 2, "baz" },
                                                  { 3, "ham" }, { 4, "spam" }, { 5, "egg" } };
  unordered_map <int, string>   expected (expected_vector.begin (), expected_vector.end ());

  map.validate_integrity ();
  BOOST_CHECK_EQUAL (map, expected);

  if (implementation::linked)
    assert_identical_order (map, keys_of (expected));
}


BOOST_AUTO_TEST_CASE_TEMPLATE (test_emplace_1,
                               implementation, test_implementations)
{
  typedef  typename implementation::template resolve <int_wrapper, int>::map_type  map_type;

  map_type  map;
  for (int k = 0; k < 50; ++k)
    {
      map.emplace (make_pair (k, k));
      map.validate_integrity ();
    }

  BOOST_CHECK_EQUAL (map.size (), 50u);
  if (implementation::linked)
    assert_identical_order (map, create_vector (int_wrapper::wrap, map.size ()));
}

#endif


BOOST_AUTO_TEST_CASE_TEMPLATE (test_insert_erase_1,
                               parameters, test_parameters_normal)
{
  COMMON_TEST_SETUP;

  map_type  map;

  foreach (const value_type& value, value_data::values1 ())
    {
      // Simply insert and immediately erase one element.
      map.insert (value);
      BOOST_CHECK (map.erase (value.first));
    }
}


BOOST_AUTO_TEST_CASE_TEMPLATE (test_copy_constructor_1,
                               parameters, test_parameters)
{
  COMMON_TEST_SETUP;

  map_type  map1 (RANGE (value_data::values1 ()));
  map_type  map2 (RANGE (value_data::values2 ()));
  map_type  map3 (map1);
  map_type  map4 (map2);

  BOOST_CHECK_EQUAL (map3, map1);
  BOOST_CHECK_EQUAL (map4, map2);

  if (linked)
    {
      assert_identical_order (map3, keys_of (map1));
      assert_identical_order (map4, keys_of (map2));
    }
}


#if MCT_CXX0X_SUPPORTED

BOOST_AUTO_TEST_CASE_TEMPLATE (test_move_constructor_1,
                               parameters, test_parameters)
{
  COMMON_TEST_SETUP;

  map_type  map (move (map_type (RANGE (value_data::values1 ()))));
  BOOST_CHECK_EQUAL (map, map_type (RANGE (value_data::values1 ())));
}

#endif  // MCT_CXX0X_SUPPORTED


BOOST_AUTO_TEST_CASE_TEMPLATE (test_assignment_1,
                               parameters, test_parameters)
{
  COMMON_TEST_SETUP;

  map_type  map1 (RANGE (value_data::values1 ()));
  map_type  map2;

  BOOST_CHECK_EQUAL (map2.size (), 0u);

  map2 = map1;
  BOOST_CHECK_EQUAL (map2, map1);

  if (linked)
    assert_identical_order (map1, keys_of (map2));
}


BOOST_AUTO_TEST_CASE_TEMPLATE (test_self_assignment_1,
                               parameters, test_parameters)
{
  COMMON_TEST_SETUP;

  map_type  map1 (RANGE (value_data::values1 ()));
  map_type  map2 (RANGE (value_data::values1 ()));

  BOOST_CHECK_EQUAL (map1, map2);
  if (linked)
    assert_identical_order (map1, keys_of (map2));

  map1 = map1;

  BOOST_CHECK_EQUAL (map1, map2);
  if (linked)
    assert_identical_order (map1, keys_of (map2));
}


#if MCT_CXX0X_SUPPORTED

BOOST_AUTO_TEST_CASE_TEMPLATE (test_move_assignment_1,
                               parameters, test_parameters)
{
  COMMON_TEST_SETUP;

  map_type  map;

  map = move (map_type (RANGE (value_data::values1 ())));
  BOOST_CHECK_EQUAL (map, map_type (RANGE (value_data::values1 ())));
}


BOOST_AUTO_TEST_CASE_TEMPLATE (test_initializer_assignment_1,
                               implementation, test_implementations)
{
  typedef  typename implementation::template resolve <int, string>::map_type  map_type;

  map_type  map { { 1, "foo" }, { 2, "bar" }, { 3, "baz" }, { 4, "bop" } };
  map = { { 4, "ham" }, { 5, "spam" }, { 6, "egg" } };

  if (implementation::linked)
    assert_identical_order (map, vector <int> { 4, 5, 6 });
}

#endif  // MCT_CXX0X_SUPPORTED


BOOST_AUTO_TEST_CASE_TEMPLATE (test_swap_1,
                               parameters, test_parameters)
{
  COMMON_TEST_SETUP;

  map_type  map1 (RANGE (value_data::values1 ()));
  map_type  map2 (RANGE (value_data::values2 ()));
  map_type  map3 (RANGE (value_data::values1 ()));
  map_type  map4 (RANGE (value_data::values2 ()));

  BOOST_CHECK_EQUAL (map1, map3);
  BOOST_CHECK_EQUAL (map2, map4);

  if (linked)
    {
      assert_identical_order (map1, keys_of (map3));
      assert_identical_order (map2, keys_of (map4));
    }

  swap (map3, map4);

  BOOST_CHECK_EQUAL (map1, map4);
  BOOST_CHECK_EQUAL (map2, map3);

  if (linked)
    {
      assert_identical_order (map1, keys_of (map4));
      assert_identical_order (map2, keys_of (map3));
    }
}


BOOST_AUTO_TEST_CASE_TEMPLATE (test_clear_1,
                               parameters, test_parameters)
{
  COMMON_TEST_SETUP;

  map_type  map (RANGE (value_data::values1 ()));
  map.clear ();
}


BOOST_AUTO_TEST_CASE_TEMPLATE (test_erase_value_1,
                               parameters, test_parameters_normal)
{
  COMMON_TEST_SETUP;

  map_type  map1 (RANGE (value_data::values1 ()));
  map_type  map2 (range_begin (value_data::values1 ()) + 1, range_end (value_data::values1 ()));

  // Make sure funny comparison functions don't ruin this test.
  if (map1.size () != map2.size ())
    {
      BOOST_CHECK       (map1.erase (value_data::values1 () [0].first));
      BOOST_CHECK_EQUAL (map1, map2);

      if (linked)
        assert_identical_order (map1, keys_of (map2));
    }
}

BOOST_AUTO_TEST_CASE_TEMPLATE (test_erase_position_1,
                               parameters, test_parameters_normal)
{
  COMMON_TEST_SETUP;

  map_type  map (RANGE (value_data::values1 ()));

  const size_t  num_passes_expected = map.size ();
  size_t        num_passes          = 0;

  for (iterator scan = map.begin (), end = map.end (); scan != end; ++num_passes)
    scan = map.erase (scan);

  BOOST_CHECK       (map.empty ());
  BOOST_CHECK_EQUAL (num_passes, num_passes_expected);
}

BOOST_AUTO_TEST_CASE_TEMPLATE (test_erase_range_1,
                               parameters, test_parameters_normal)
{
  COMMON_TEST_SETUP;

  map_type  map (RANGE (value_data::values1 ()));

  map.erase (map.begin (), map.end ());
  BOOST_CHECK (map.empty ());
}


BOOST_AUTO_TEST_CASE_TEMPLATE (test_subscription_1,
                               parameters, test_parameters)
{
  COMMON_TEST_SETUP;

  map_type  map;
  int       k = 0;
  foreach (const key_type& key, key_data::values1 ())
    map.subscript (key, mapped_data::generate (k++));
}


BOOST_AUTO_TEST_CASE_TEMPLATE (test_comparison_1,
                               parameters, test_parameters)
{
  COMMON_TEST_SETUP;

  map_type  map1 (RANGE (value_data::values1 ()));
  map_type  map2 (RANGE (value_data::values1 ()));
  map_type  map3 (RANGE (value_data::values2 ()));
  map_type  map4 (RANGE (value_data::values2 ()));

  BOOST_CHECK_EQUAL (map1, map2);
  BOOST_CHECK_EQUAL (map3, map4);
  BOOST_CHECK_NE    (map1, map3);
}


BOOST_AUTO_TEST_CASE_TEMPLATE (test_modification_through_iterator_1,
                               parameters, test_parameters)
{
  COMMON_TEST_SETUP;

  map_type  map;

  map.insert (make_pair (key_data::values1 () [0], mapped_type ()));
  map.assign_through_iterator (map.find (key_data::values1 () [0]), mapped_data::values1 () [0]);

  BOOST_CHECK_EQUAL (map.at (key_data::values1 () [0]), mapped_data::values1 () [0]);
}


BOOST_AUTO_TEST_CASE_TEMPLATE (test_growth_1,
                               parameters, test_parameters_std_equal)
{
  COMMON_TEST_SETUP;

  // Note: fairly small, because testing after each step is slow.
  map_type  map;
  for (int k = 0; k < 200; ++k)
    map.insert (make_pair (key_data::generate (k), mapped_data::generate (k)));

  BOOST_CHECK_EQUAL (map.size (), 200u);
  if (linked)
    assert_identical_order (map, create_vector (key_data::generate, map.size ()));
}

BOOST_AUTO_TEST_CASE_TEMPLATE (test_shrink_1,
                               parameters, test_parameters_std_equal_normal)
{
  COMMON_TEST_SETUP;

  const size_t                    num_items = 200;
  vector <assignable_value_type>  items (create_vector (value_data::generate, num_items));
  map_type                        map   (items.begin (), items.end ());

  BOOST_CHECK_EQUAL (map.size (), num_items);

  const_iterator  almost_end = map.end ();
  for (int k = 0; k < 10; ++k)
    --almost_end;

  map.erase (map.begin (), almost_end);

  BOOST_CHECK_EQUAL (map.size (), 10u);
  if (linked)
    assert_identical_order (map, create_vector (key_data::generate, num_items, num_items - 10));

  map.rehash (32);

  BOOST_CHECK_EQUAL (map.bucket_count (), 32u);
  if (linked)
    assert_identical_order (map, create_vector (key_data::generate, num_items, num_items - 10));
}

BOOST_AUTO_TEST_CASE_TEMPLATE (test_tiny_map_1,
                               parameters, test_parameters)
{
  COMMON_TEST_SETUP;

  float  load_factors[] = { 0.01, 0.1, 0.25, 0.5, 0.75, 0.9, 0.99 };

  foreach (float load_factor, load_factors)
    {
      BOOST_TEST_CHECKPOINT ("testing with maximum load factor " << load_factor);

      map_type  map (1);
      map.max_load_factor (load_factor);

      for (int k = 0; k < 50; ++k)
        map.insert (value_data::generate (k));

      if (linked)
        assert_identical_order (map, create_vector (key_data::generate, 50));
    }
}


BOOST_AUTO_TEST_CASE_TEMPLATE (test_intrusive_bucket_size_1,
                               implementation, test_implementations)
{
  {
    typedef  test_map <typename implementation::template resolve <ham, int>::map_type>  map_type;

    map_type  map;

    BOOST_CHECK       (!map_type::bucket_type::KEEPS_HASHES);
    BOOST_CHECK_EQUAL (sizeof (typename map_type::iterator), sizeof (pair <ham, int>*));
  }

  {
    typedef  test_map <typename implementation::template resolve <int, ham>::map_type>  map_type;

    map_type  map;

    BOOST_CHECK       (!map_type::bucket_type::KEEPS_HASHES);
    BOOST_CHECK_EQUAL (sizeof (typename map_type::iterator), sizeof (pair <int, ham>*));
  }

  {
    typedef  test_map <typename implementation::template resolve <ham, ham>::map_type>  map_type;

    map_type  map;

    BOOST_CHECK       (!map_type::bucket_type::KEEPS_HASHES);
    BOOST_CHECK_EQUAL (sizeof (typename map_type::iterator), sizeof (pair <ham, ham>*));
  }
}


BOOST_AUTO_TEST_SUITE_END ()


// Local variables:
// mode: c++
// c-basic-offset: 2
// indent-tabs-mode: nil
// fill-column: 90
// End:
