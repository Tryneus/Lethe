// Copyright (c) 2010 Paul Pogonyshev.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.


#ifndef MCT_TESTS_MAP_PARAMETERS_HPP
#define MCT_TESTS_MAP_PARAMETERS_HPP


#include <boost/mpl/copy_if.hpp>
#include <boost/mpl/push_back.hpp>
#include <boost/mpl/vector.hpp>


template <typename Implementation,
          typename Key,
          typename Mapped,
          typename Hash  = MCT_HASH_NAMESPACE::hash <Key>,
          typename Equal = equal_to <Key>,
          bool _keep_hashes = false>
struct Parameters
{
  typedef  Implementation                      implementation;
  typedef  Key                                 key_type;
  typedef  Mapped                              mapped_type;
  typedef  pair <const key_type, mapped_type>  value_type;
  typedef  pair <key_type, mapped_type>        assignable_value_type;
  typedef  Hash                                hasher;
  typedef  Equal                               equal_to;

  static  const bool  keep_hashes = _keep_hashes;
  static  const bool  linked      = Implementation::linked;

  typedef  test_map <typename Implementation::
                     template resolve <Key, Mapped, Hash, Equal, _keep_hashes>::map_type>
           map_type;
};


// To speed compilation up we list just a few possible combinations for each base type.
typedef  mpl::vector <Parameters <Plain, int, int>,
                      Parameters <Linked, int, int>,
                      Parameters <Forward, int, int>,
                      Parameters <Plain, int, string, int_hasher_1>,
                      Parameters <Plain, int, string,
                                  MCT_HASH_NAMESPACE::hash <int>, equal_to <int>, true>,
#                   if MCT_HAVE_LONG_LONG
                      Parameters <Plain, unsigned long long, string>,
                      Parameters <Plain, unsigned long long, int, unsigned_long_long_hasher>,
                      Parameters <Linked, unsigned long long, string,
                                  MCT_HASH_NAMESPACE::hash <unsigned long long>,
                                  equal_to <unsigned long long>, true>,
#                   endif
                      Parameters <Plain, string, int>,
                      Parameters <Plain, string, string, string_hasher_1>,
                      Parameters <Plain, string, int, string_hasher_1, equal_to <string>, true>,
                      Parameters <Linked, string, string>,
                      Parameters <Plain, foo, int>,
                      Parameters <Linked, foo, string>,
                      Parameters <Plain, bar, int>,
                      Parameters <Linked, bar, int> >
         test_parameters_std_equal;

typedef  mpl::push_back <test_parameters_std_equal,
                         Parameters <Plain, int, string, int_hasher_special,
                                     int_comparator_special> >::type
         test_parameters;

template <typename parameters>
struct is_normal
{
  typedef  mpl::bool_<parameters::implementation::normal>  type;
};

typedef  mpl::copy_if <test_parameters_std_equal, is_normal <mpl::_1> >::type
         test_parameters_std_equal_normal;

typedef  mpl::copy_if <test_parameters, is_normal <mpl::_1> >::type
         test_parameters_normal;

typedef  mpl::vector <Plain, Linked, Forward>
         test_implementations;


#define COMMON_TEST_SETUP                                                       \
  typedef  typename parameters::map_type               map_type;                \
  typedef  typename map_type::iterator                 iterator;                \
  typedef  typename map_type::const_iterator           const_iterator;          \
  typedef  typename parameters::key_type               key_type;                \
  typedef  typename parameters::value_type             value_type;              \
  typedef  typename parameters::assignable_value_type  assignable_value_type;   \
  typedef  typename parameters::mapped_type            mapped_type;             \
  typedef  typename parameters::hasher                 hasher;                  \
  typedef  typename parameters::equal_to               equal_to;                \
  typedef  Data <key_type>                             key_data;                \
  typedef  Data <assignable_value_type>                value_data;              \
  typedef  Data <mapped_type>                          mapped_data;             \
  const bool  linked = parameters::linked


#endif  // Multi-inclusion guard.


// Local variables:
// mode: c++
// c-basic-offset: 2
// indent-tabs-mode: nil
// fill-column: 90
// End:
