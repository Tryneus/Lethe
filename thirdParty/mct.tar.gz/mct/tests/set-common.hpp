// Copyright (c) 2009, 2010 Paul Pogonyshev.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.


#ifdef MCT_TESTS_COMMON_HPP
# error common.hpp must not be included before set-common.hpp
#endif


#ifndef MCT_TESTS_SET_COMMON_HPP
#define MCT_TESTS_SET_COMMON_HPP


#include "tests/common.hpp"

#include <boost/test/unit_test.hpp>

#if HAVE_UNORDERED_SET
# include <unordered_set>
using std::unordered_set;

#elif HAVE_TR1_UNORDERED_SET
# include <tr1/unordered_set>
using std::tr1::unordered_set;

#elif HAVE_BOOST_UNORDERED_SET_HPP
# include <boost/unordered_set.hpp>
using boost::unordered_set;
#endif


namespace mct
{

#define TEST_SET_OUTPUT(tested_set_type)                                                \
  template <typename Value, typename Hash, typename Equal, typename Allocator,          \
            bool keep_hashes>                                                           \
  ostream&                                                                              \
  operator<< (ostream& stream,                                                          \
              const tested_set_type <Value, Hash, Equal, Allocator, keep_hashes>& set)  \
  {                                                                                     \
    return print_range (stream, "{}", set.begin (), set.end ());                        \
  }

  TEST_SET_OUTPUT (closed_hash_set)
  TEST_SET_OUTPUT (linked_hash_set)
  TEST_SET_OUTPUT (forward_hash_set)

}


namespace std
{

  template <typename Value, typename Hash, typename Equal, typename Allocator>
  ostream&
  operator<< (ostream& stream, const unordered_set <Value, Hash, Equal, Allocator>& set)
  {
    return print_range (stream, "{}", set.begin (), set.end ());
  }

}


#define TEST_SET_COMPARISON(tested_set_type)                                                    \
  template <typename Value, typename Hash, typename Equal,                                      \
            typename Allocator1, typename Allocator2, bool keep_hashes>                         \
  bool                                                                                          \
  operator== (const tested_set_type <Value, Hash, Equal, Allocator1, keep_hashes>& tested_set,  \
              const unordered_set <Value, Hash, Equal, Allocator2>& robust_set)                 \
  {                                                                                             \
    if (tested_set.size () != robust_set.size ())                                               \
      return false;                                                                             \
    foreach (const Value& value, robust_set)                                                    \
      {                                                                                         \
        if (!contains (tested_set, value))                                                      \
          return false;                                                                         \
      }                                                                                         \
    return true;                                                                                \
  }

TEST_SET_COMPARISON (closed_hash_set)
TEST_SET_COMPARISON (linked_hash_set)
TEST_SET_COMPARISON (forward_hash_set)


template <typename Implementation>
class test_set_base : public Implementation
{
public:

  typedef  Implementation                                implementation_type;

  // Make the type public for the purpose of testing.
  typedef  typename implementation_type::bucket_type     bucket_type;

  typedef  typename implementation_type::key_type        key_type;
  typedef  typename implementation_type::value_type      value_type;
  typedef  typename implementation_type::iterator        iterator;
  typedef  typename implementation_type::const_iterator  const_iterator;
  typedef  typename implementation_type::hasher          hasher;
  typedef  typename implementation_type::key_equal       key_equal;
  typedef  typename implementation_type::allocator_type  allocator_type;
  typedef  typename allocator_type::base_type            allocator_base;

protected:

  // Note that we don't use leak test allocator for the set we check against.
  typedef  unordered_set <key_type, hasher, key_equal, allocator_base>  robust_type;


  robust_type  _valid;


public:

  explicit
  test_set_base (size_t                num_buckets = 0,
                 const hasher&         hash        = hasher (),
                 const key_equal&      equal       = key_equal (),
                 const allocator_type& allocator   = allocator_type ())
    : implementation_type (num_buckets, hash, equal, allocator),
      _valid              (num_buckets, hash, equal, allocator)
  {
    validate ();
  }

# if MCT_CXX0X_SUPPORTED

  test_set_base (test_set_base&& that)
    : implementation_type (move (that)),
      _valid              (that._valid)
  { }

  test_set_base (initializer_list <value_type> initializer,
                 size_t                num_buckets = 0,
                 const hasher&         hash        = hasher (),
                 const key_equal&      equal       = key_equal (),
                 const allocator_type& allocator   = allocator_type ())
    : implementation_type (initializer, num_buckets, hash, equal, allocator),
      _valid              (num_buckets, hash, equal, allocator)
  {
    // Not requiring that the robust implementation has this constructor.
    _valid.insert (initializer.begin (), initializer.end ());
    validate ();
  }

# endif  // MCT_CXX0X_SUPPORTED

  template <typename InputIterator>
  test_set_base (InputIterator begin, InputIterator end,
                 size_t                num_buckets = 0,
                 const hasher&         hash        = hasher (),
                 const key_equal&      equal       = key_equal (),
                 const allocator_type& allocator   = allocator_type ())
    : implementation_type (begin, end, num_buckets, hash, equal, allocator),
      _valid              (begin, end, num_buckets, hash, equal, allocator)
  {
    validate ();
  }

  ~test_set_base ()
  {
    if (this->_data.buckets)
      validate ();
  }


  test_set_base&
  operator= (const test_set_base& that)
  {
    implementation_type::operator= (that);
    this->_valid = that._valid;
    validate ();
    return *this;
  }

# if MCT_CXX0X_SUPPORTED

  test_set_base&
  operator= (test_set_base&& that)
  {
    implementation_type::operator= (move (that));
    this->_valid = that._valid;
    validate ();
    return *this;
  }

  test_set_base&
  operator= (initializer_list <value_type> initializer)
  {
    implementation_type::operator= (initializer);
    _valid.clear ();
    _valid.insert (initializer.begin (), initializer.end ());
    validate ();
    return *this;
  }

# endif  // MCT_CXX0X_SUPPORTED


  pair <iterator, bool>
  insert (const value_type& value)
  {
    const pair <iterator, bool>  result (implementation_type::insert (value));
    _valid.insert (value);
    validate ();
    return result;
  }

  iterator
  insert (const_iterator hint, const value_type& value)
  {
    const iterator  result (implementation_type::insert (hint, value));
    _valid.insert (_valid.end (), value);
    validate ();
    return result;
  }

  template <typename InputIterator>
  void
  insert (InputIterator begin, InputIterator end)
  {
    implementation_type::insert (begin, end);
    _valid.insert (begin, end);
    validate ();
  }


  void
  clear ()
  {
    implementation_type::clear ();
    _valid.clear ();
    validate ();
  }


  void
  swap (test_set_base& that)
  {
    implementation_type::swap (that);
    _valid.swap (that._valid);
    validate ();
    that.validate ();
  }


  void
  rehash (size_t num_buckets)
  {
    implementation_type::rehash (num_buckets);
    validate ();
  }


  void
  validate () const
  {
    implementation_type::validate_integrity ();
    BOOST_REQUIRE_EQUAL (*this, _valid);
  }
};


template <typename implementation_type, typename family = typename implementation_type::_family>
class test_set;


template <typename implementation_type>
class test_set <implementation_type, impl::closed_table_family>
  : public test_set_base <implementation_type>
{
  typedef  test_set_base <implementation_type>  base_type;

public:

  typedef  typename base_type::key_type         key_type;
  typedef  typename base_type::value_type       value_type;
  typedef  typename base_type::iterator         iterator;
  typedef  typename base_type::const_iterator   const_iterator;
  typedef  typename base_type::hasher           hasher;
  typedef  typename base_type::key_equal        key_equal;
  typedef  typename base_type::allocator_type   allocator_type;


public:

  explicit
  test_set (size_t                num_buckets = 0,
            const hasher&         hash        = hasher (),
            const key_equal&      equal       = key_equal (),
            const allocator_type& allocator   = allocator_type ())
    : base_type (num_buckets, hash, equal, allocator)
  { }

# if MCT_CXX0X_SUPPORTED

  test_set (test_set&& that)
    : base_type (move (that))
  { }

  test_set (initializer_list <value_type> initializer,
            size_t                num_buckets = 0,
            const hasher&         hash        = hasher (),
            const key_equal&      equal       = key_equal (),
            const allocator_type& allocator   = allocator_type ())
    : base_type (initializer, num_buckets, hash, equal, allocator)
  { }

# endif  // MCT_CXX0X_SUPPORTED

  template <typename InputIterator>
  test_set (InputIterator begin, InputIterator end,
            size_t                num_buckets = 0,
            const hasher&         hash        = hasher (),
            const key_equal&      equal       = key_equal (),
            const allocator_type& allocator   = allocator_type ())
    : base_type (begin, end, num_buckets, hash, equal, allocator)
  { }


  bool
  erase (const key_type& key)
  {
    const bool  result = implementation_type::erase (key);
    BOOST_REQUIRE_EQUAL (result, this->_valid.erase (key));
    this->validate ();
    return result;
  }

  iterator
  erase (const_iterator position)
  {
    this->_valid.erase (*position);
    const iterator  result = implementation_type::erase (position);
    this->validate ();
    return result;
  }

  iterator
  erase (const_iterator first, const_iterator last)
  {
    // Order is not required to be the same; emulate.
    for (const_iterator scan = first; scan != last; ++scan)
      this->_valid.erase (*scan);

    const iterator  result = implementation_type::erase (first, last);
    this->validate ();
    return result;
  }
};


template <typename implementation_type>
class test_set <implementation_type, impl::linked_table_family>
  : public test_set <implementation_type, impl::closed_table_family>
{
  typedef  test_set <implementation_type, impl::closed_table_family>  base_type;

public:

  typedef  typename base_type::key_type         key_type;
  typedef  typename base_type::value_type       value_type;
  typedef  typename base_type::iterator         iterator;
  typedef  typename base_type::const_iterator   const_iterator;
  typedef  typename base_type::hasher           hasher;
  typedef  typename base_type::key_equal        key_equal;
  typedef  typename base_type::allocator_type   allocator_type;


public:

  explicit
  test_set (size_t                num_buckets = 0,
            const hasher&         hash        = hasher (),
            const key_equal&      equal       = key_equal (),
            const allocator_type& allocator   = allocator_type ())
    : base_type (num_buckets, hash, equal, allocator)
  { }

# if MCT_CXX0X_SUPPORTED

  test_set (test_set&& that)
    : base_type (move (that))
  { }

  test_set (initializer_list <value_type> initializer,
            size_t                num_buckets = 0,
            const hasher&         hash        = hasher (),
            const key_equal&      equal       = key_equal (),
            const allocator_type& allocator   = allocator_type ())
    : base_type (initializer, num_buckets, hash, equal, allocator)
  { }

# endif  // MCT_CXX0X_SUPPORTED

  template <typename InputIterator>
  test_set (InputIterator begin, InputIterator end,
            size_t                num_buckets = 0,
            const hasher&         hash        = hasher (),
            const key_equal&      equal       = key_equal (),
            const allocator_type& allocator   = allocator_type ())
    : base_type (begin, end, num_buckets, hash, equal, allocator)
  { }


  void
  pop_front ()
  {
    this->_valid.erase (this->front ());
    implementation_type::pop_front ();
    this->validate ();
  }

  void
  pop_back ()
  {
    this->_valid.erase (this->back ());
    implementation_type::pop_back ();
    this->validate ();
  }
};


template <typename implementation_type>
class test_set <implementation_type, impl::forward_table_family>
  : public test_set_base <implementation_type>
{
  typedef  test_set_base <implementation_type>  base_type;

public:

  typedef  typename base_type::key_type         key_type;
  typedef  typename base_type::value_type       value_type;
  typedef  typename base_type::iterator         iterator;
  typedef  typename base_type::const_iterator   const_iterator;
  typedef  typename base_type::hasher           hasher;
  typedef  typename base_type::key_equal        key_equal;
  typedef  typename base_type::allocator_type   allocator_type;


public:

  explicit
  test_set (size_t                num_buckets = 0,
            const hasher&         hash        = hasher (),
            const key_equal&      equal       = key_equal (),
            const allocator_type& allocator   = allocator_type ())
    : base_type (num_buckets, hash, equal, allocator)
  { }

# if MCT_CXX0X_SUPPORTED

  test_set (test_set&& that)
    : base_type (move (that))
  { }

  test_set (initializer_list <value_type> initializer,
            size_t                num_buckets = 0,
            const hasher&         hash        = hasher (),
            const key_equal&      equal       = key_equal (),
            const allocator_type& allocator   = allocator_type ())
    : base_type (initializer, num_buckets, hash, equal, allocator)
  { }

# endif  // MCT_CXX0X_SUPPORTED

  template <typename InputIterator>
  test_set (InputIterator begin, InputIterator end,
            size_t                num_buckets = 0,
            const hasher&         hash        = hasher (),
            const key_equal&      equal       = key_equal (),
            const allocator_type& allocator   = allocator_type ())
    : base_type (begin, end, num_buckets, hash, equal, allocator)
  { }


  void
  pop_front ()
  {
    this->_valid.erase (this->front ());
    implementation_type::pop_front ();
    this->validate ();
  }


  void
  erase_after (const_iterator after)
  {
    const_iterator  position = after;
    this->_valid.erase (*++position);
    implementation_type::erase_after (after);
    this->validate ();
  }

  void
  erase_after (const_iterator after, const_iterator last)
  {
    // Order is not required to be the same; emulate.
    for (const_iterator scan = after; ++scan != last;)
      this->_valid.erase (*scan);

    implementation_type::erase_after (after, last);
    this->validate ();
  }
};


template <typename implementation_type, typename family>
inline  void
swap (test_set <implementation_type, family>& set1, test_set <implementation_type, family>& set2)
{
  set1.swap (set2);
}


struct Plain
{
  template <typename Type,
            typename Hash    = MCT_HASH_NAMESPACE::hash <Type>,
            typename Equal   = equal_to <Type>,
            bool keep_hashes = false>
  struct resolve
  {
    typedef  closed_hash_set <Type, Hash, Equal,
                              leak_test_allocator <allocator <Type> >,
                              keep_hashes>
             set_type;
  };

  static  const bool  normal = true;
  static  const bool  linked = false;

  // Hide difference in available methods: for non-linked sets 'before' is just ignored.
  template <typename Set>
  static  pair <typename Set::iterator, bool>
  insert_before (Set& set, typename Set::const_iterator before,
                 const typename Set::value_type& value)
  {
    return set.insert (value);
  }
};


struct Linked
{
  template <typename Type,
            typename Hash    = MCT_HASH_NAMESPACE::hash <Type>,
            typename Equal   = equal_to <Type>,
            bool keep_hashes = false>
  struct resolve
  {
    typedef  linked_hash_set <Type, Hash, Equal,
                              leak_test_allocator <allocator <Type> >,
                              keep_hashes>
             set_type;
  };

  static  const bool  normal = true;
  static  const bool  linked = true;

  template <typename Set>
  static  pair <typename Set::iterator, bool>
  insert_before (Set& set, typename Set::const_iterator before,
                 const typename Set::value_type& value)
  {
    return set.insert (before, value);
  }
};


struct Forward
{
  template <typename Type,
            typename Hash    = MCT_HASH_NAMESPACE::hash <Type>,
            typename Equal   = equal_to <Type>,
            bool keep_hashes = false>
  struct resolve
  {
    typedef  forward_hash_set <Type, Hash, Equal,
                               leak_test_allocator <allocator <Type> >,
                               keep_hashes>
             set_type;
  };

  static  const bool  normal = false;
  static  const bool  linked = true;

  template <typename Set>
  static  pair <typename Set::iterator, bool>
  insert_before (Set& set, typename Set::const_iterator before,
                 const typename Set::value_type& value)
  {
    return set.insert (before, value);
  }
};


#endif  // Multi-inclusion guard.


// Local variables:
// mode: c++
// c-basic-offset: 2
// indent-tabs-mode: nil
// fill-column: 90
// End:
