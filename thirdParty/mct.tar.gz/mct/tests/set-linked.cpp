// Copyright (c) 2010 Paul Pogonyshev.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.


// Even though we perform our own integrity validation, and even comparisons to a known
// good implementation in our tests, we still let the tables validate themselves with
// MCT_SELF_VALIDATION.  If nothing else, this ensures that MCT_SELF_VALIDATION behaves
// correctly on valid tables.
#undef  MCT_SELF_VALIDATION
#define MCT_SELF_VALIDATION     1

#include "tests/set-common.hpp"
#include "tests/set-parameters.hpp"


BOOST_AUTO_TEST_SUITE (set_linked)


BOOST_AUTO_TEST_CASE_TEMPLATE (test_front_1,
                               parameters, test_parameters_std_equal_linked)
{
  COMMON_TEST_SETUP;

  set_type  set (RANGE (data::values1 ()));
  BOOST_CHECK_EQUAL (set.front (), data::values1 () [0]);

  set.pop_front ();
  BOOST_CHECK_EQUAL (set.front (), data::values1 () [1]);
}

BOOST_AUTO_TEST_CASE_TEMPLATE (test_back_1,
                               parameters, test_parameters_std_equal_linked)
{
  COMMON_TEST_SETUP;

  set_type  set (RANGE (data::values1 ()));
  BOOST_CHECK_EQUAL (set.back (), *(range_end (data::values1 ()) - 1));
}

BOOST_AUTO_TEST_CASE_TEMPLATE (test_back_2,
                               parameters, test_parameters_std_equal_double_linked)
{
  COMMON_TEST_SETUP;

  set_type  set (RANGE (data::values1 ()));
  BOOST_CHECK_EQUAL (set.back (), *(range_end (data::values1 ()) - 1));

  set.pop_back ();
  BOOST_CHECK_EQUAL (set.back (), *(range_end (data::values1 ()) - 2));
}


BOOST_AUTO_TEST_CASE_TEMPLATE (test_erase_after_1,
                               parameters, test_parameters_forward)
{
  COMMON_TEST_SETUP;

  set_type  set (RANGE (data::values1 ()));

  set.erase_after (set.before_begin ());

  // Erasing the last item.
  for (const_iterator scan = set.begin (); ;)
    {
      const_iterator  next = scan;
      ++next;

      if (next != set.before_end ())
        scan = next;
      else
        {
          set.erase_after (scan);
          break;
        }
    }
}

BOOST_AUTO_TEST_CASE_TEMPLATE (test_erase_after_range_1,
                               parameters, test_parameters_forward)
{
  COMMON_TEST_SETUP;

  set_type  set (RANGE (data::values1 ()));

  // Erase everything but the first and the last items.
  set.erase_after (set.begin (), set.before_end ());

  BOOST_CHECK_EQUAL (set.size  (), 2u);
  BOOST_CHECK_EQUAL (set.front (), data::values1 () [0]);
  BOOST_CHECK_EQUAL (set.back  (), data::values1 () [range_size (data::values1 ()) - 1u]);
}


BOOST_AUTO_TEST_CASE_TEMPLATE (test_relink_1,
                               parameters, test_parameters_double_linked)
{
  COMMON_TEST_SETUP;

  vector <type>  initializers (create_vector (data::generate, 50));
  set_type       set (initializers.begin (), initializers.end ());

  assert_identical_order (set, initializers);

  set.relink (set.find (data::generate (40)), set.find (data::generate (20)));
  set.validate_integrity ();

  initializers.erase  (find (initializers.begin (), initializers.end (), data::generate (20)));
  initializers.insert (find (initializers.begin (), initializers.end (), data::generate (40)),
                       data::generate (20));

  assert_identical_order (set, initializers);

  // The following "moves" have no effect.

  set.relink (set.find (data::generate (5)), set.find (data::generate (5)));
  set.validate_integrity ();

  assert_identical_order (set, initializers);

  set.relink (set.find (data::generate (15)), set.find (data::generate (14)));
  set.validate_integrity ();

  assert_identical_order (set, initializers);
}

BOOST_AUTO_TEST_CASE_TEMPLATE (test_relink_after_1,
                               parameters, test_parameters_forward)
{
  COMMON_TEST_SETUP;

  vector <type>  initializers (create_vector (data::generate, 50));
  set_type       set (initializers.begin (), initializers.end ());

  assert_identical_order (set, initializers);

  set.relink_after (set.before_end (), set.before_begin ());
  set.validate_integrity ();

  type  first (initializers.front ());
  initializers.erase     (initializers.begin ());
  initializers.push_back (first);

  assert_identical_order (set, initializers);

  // The following "moves" have no effect.

  set.relink_after (set.find (data::generate (5)), set.find (data::generate (5)));
  set.validate_integrity ();

  assert_identical_order (set, initializers);

  set.relink_after (set.find (data::generate (15)), set.find (data::generate (14)));
  set.validate_integrity ();

  assert_identical_order (set, initializers);
}

BOOST_AUTO_TEST_CASE_TEMPLATE (test_reverse_1,
                               parameters, test_parameters_linked)
{
  COMMON_TEST_SETUP;

  vector <type>  initializers (create_vector (data::generate, 50));
  set_type       set (initializers.begin (), initializers.end ());

  assert_identical_order (set, initializers);

  set.reverse ();
  set.validate_integrity ();
  reverse (initializers.begin (), initializers.end ());

  assert_identical_order (set, initializers);
}


BOOST_AUTO_TEST_SUITE_END ()


// Local variables:
// mode: c++
// c-basic-offset: 2
// indent-tabs-mode: nil
// fill-column: 90
// End:
