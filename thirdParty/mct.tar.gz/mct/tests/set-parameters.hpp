// Copyright (c) 2009, 2010 Paul Pogonyshev.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.


#ifndef MCT_TESTS_SET_PARAMETERS_HPP
#define MCT_TESTS_SET_PARAMETERS_HPP


#include <boost/mpl/copy_if.hpp>
#include <boost/mpl/end.hpp>
#include <boost/mpl/insert_range.hpp>
#include <boost/mpl/vector.hpp>


template <typename Implementation,
          typename Type,
          typename Hash  = MCT_HASH_NAMESPACE::hash <Type>,
          typename Equal = equal_to <Type>,
          bool _keep_hashes = false>
struct Parameters
{
  typedef  Implementation  implementation;
  typedef  Type            type;
  typedef  Hash            hasher;
  typedef  Equal           equal_to;

  static  const bool  keep_hashes = _keep_hashes;

  typedef  test_set <typename Implementation::
                     template resolve <Type, Hash, Equal, _keep_hashes>::set_type>
           set_type;
};


// To speed compilation up we list just a few possible combinations for each base type.

// 'std_equal' need to never compare different elements in 'data::valueN' equal and not
// compare different elements returned from data::generate() equal, at least for
// reasonably small iteration numbers.
typedef  mpl::vector <Parameters <Plain, int>,
                      Parameters <Plain, int, int_hasher_1>,
                      Parameters <Plain, int,
                                  MCT_HASH_NAMESPACE::hash <int>, equal_to <int>, true>,
                      Parameters <Plain, ham>,
                      Parameters <Linked, int>,
                      Parameters <Forward, int>,
#                   if MCT_HAVE_LONG_LONG
                      Parameters <Plain, unsigned long long>,
                      Parameters <Plain, unsigned long long, unsigned_long_long_hasher>,
                      Parameters <Linked, unsigned long long, unsigned_long_long_hasher,
                                  equal_to <unsigned long long>, true>,
#                   endif
                      Parameters <Plain, string>,
                      Parameters <Plain, string, string_hasher_1>,
                      Parameters <Plain, string, string_hasher_1, equal_to <string>, true>,
                      Parameters <Linked, string, string_hasher_1>,
                      Parameters <Plain, foo>,
                      Parameters <Linked, foo>,
                      Parameters <Plain, bar>,
                      Parameters <Linked, bar> >
         test_parameters_std_equal;

typedef  mpl::vector <Parameters <Plain, int, int_hasher_special,
                                  int_comparator_special> >
         test_parameters_non_std_equal;

typedef  mpl::insert_range <test_parameters_std_equal,
                            mpl::end <test_parameters_std_equal>::type,
                            test_parameters_non_std_equal>::type
         test_parameters;

template <typename parameters>
struct is_normal
{
  typedef  mpl::bool_<parameters::implementation::normal>  type;
};

template <typename parameters>
struct is_linked
{
  typedef  mpl::bool_<parameters::implementation::linked>  type;
};

template <typename parameters>
struct robust_iterator_validation
{
  typedef  mpl::bool_<parameters::set_type::iterator::ROBUST_PRECONDITION_CHECKING>  type;
};

template <typename parameters>
struct is_external_use_set
{
  typedef  mpl::bool_<supports_external_use <typename parameters::set_type::value_type>::value>
           type;
};

typedef  mpl::copy_if <test_parameters_std_equal, is_normal <mpl::_1> >::type
         test_parameters_std_equal_normal;

typedef  mpl::copy_if <test_parameters, is_normal <mpl::_1> >::type
         test_parameters_normal;

typedef  mpl::copy_if <test_parameters, is_linked <mpl::_1> >::type
         test_parameters_linked;

typedef  mpl::copy_if <test_parameters_std_equal, is_linked <mpl::_1> >::type
         test_parameters_std_equal_linked;

typedef  mpl::copy_if <test_parameters, mpl::and_<is_linked <mpl::_1>,
                                                  is_normal <mpl::_1> > >::type
         test_parameters_double_linked;

typedef  mpl::copy_if <test_parameters_std_equal, mpl::and_<is_linked <mpl::_1>,
                                                            is_normal <mpl::_1> > >::type
         test_parameters_std_equal_double_linked;

typedef  mpl::copy_if <test_parameters, mpl::and_<is_linked <mpl::_1>,
                                                  mpl::not_<is_normal <mpl::_1> > > >::type
         test_parameters_forward;

typedef  mpl::copy_if <test_parameters, robust_iterator_validation <mpl::_1> >::type
         test_parameters_robust_iterator_validation;

typedef  mpl::copy_if <test_parameters, mpl::and_<is_normal <mpl::_1>,
                                                  robust_iterator_validation <mpl::_1> > >::type
         test_parameters_normal_robust_iterator_validation;

typedef  mpl::copy_if <test_parameters, is_external_use_set <mpl::_1> >::type
         test_parameters_supporting_external_use;

typedef  mpl::vector <Plain, Linked, Forward>
         test_implementations;


#define COMMON_TEST_SETUP                                       \
  typedef  typename parameters::implementation  implementation; \
  typedef  typename parameters::set_type        set_type;       \
  typedef  typename set_type::iterator          iterator;       \
  typedef  typename set_type::const_iterator    const_iterator; \
  typedef  typename parameters::type            type;           \
  typedef  typename parameters::hasher          hasher;         \
  typedef  typename parameters::equal_to        equal_to;       \
  typedef  Data <type>                          data;           \
  const bool  linked = parameters::implementation::linked


#endif  // Multi-inclusion guard.


// Local variables:
// mode: c++
// c-basic-offset: 2
// indent-tabs-mode: nil
// fill-column: 90
// End:
